# manMetaVAR 0.9.5

* Edits to summary functions.
* Docker Hub tag: 2025-11-10-16300747

# manMetaVAR 0.9.4

* Added `FitMplus()`.
* Docker Hub tag: 2025-11-05-15174966
* Used in the simulations.

# manMetaVAR 0.9.3

* Edits to `.MxHelperEnsureGoodHessian()`.

# manMetaVAR 0.9.2

* `max_attempts` from `1000` to `10` in `FitDTVAR()`.

# manMetaVAR 0.9.1

* Initial setup
