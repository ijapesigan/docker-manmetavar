#
#   Copyright 2007-2019 by the individuals mentioned in the source code history
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
# 
#        http://www.apache.org/licenses/LICENSE-2.0
# 
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.


require(OpenMx)

x = mxVersion()
# OpenMx version: 2.0.0.3627
# R version: R version 3.1.0 (2014-04-10)
# Platform: x86_64-apple-darwin10.8.0
# Default optimizer: NPSOL

omxCheckEquals(x, packageVersion("OpenMx"))
