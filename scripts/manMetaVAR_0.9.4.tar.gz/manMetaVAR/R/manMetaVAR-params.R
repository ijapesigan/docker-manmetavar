#' Simulation Parameters
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @format A dataframe with 25 rows and 3 columns:
#'
#' \describe{
#'   \item{taskid}{
#'     Simulation Task ID.
#'   }
#'   \item{n}{
#'     Sample size.
#'   }
#'   \item{time}{
#'     Number of measurement occassions.
#'   }
#'   \item{dynamics}{
#'     Process dynamics.
#'     `1` for stable reciprocal regulation,
#'     `2` for escalating co-activation, and
#'     `3` for adaptive recovery.
#'   }
#' }
#'
#' @keywords data parameters
"params"
