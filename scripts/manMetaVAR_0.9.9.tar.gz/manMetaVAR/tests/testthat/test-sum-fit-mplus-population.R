testthat::test_that(
  "Mplus parameters align with the calibrated population",
  {
    parameter_names <- c(
      paste0(
        "alpha[",
        seq_len(6),
        ",1]"
      ),
      "tau_sqr[1,1]",
      "tau_sqr[2,1]",
      "tau_sqr[2,2]",
      "tau_sqr[3,3]",
      "tau_sqr[4,3]",
      "tau_sqr[5,3]",
      "tau_sqr[6,3]",
      "tau_sqr[4,4]",
      "tau_sqr[5,4]",
      "tau_sqr[6,4]",
      "tau_sqr[5,5]",
      "tau_sqr[6,5]",
      "tau_sqr[6,6]"
    )
    parameter <- setNames(
      101:119,
      parameter_names
    )
    population_object <- list(
      conditions = list(
        list(
          heterogeneity = 2,
          mu_mu = c(0, 0),
          beta_mu = matrix(
            data = 0,
            nrow = 2,
            ncol = 2
          ),
          parameter = parameter
        )
      )
    )
    mplus_names <- c(
      "mean(mu[1,1])",
      "mean(mu[2,1])",
      "mean(beta[1,1])",
      "mean(beta[2,1])",
      "mean(beta[1,2])",
      "mean(beta[2,2])",
      "cov(mu[1,1],mu[1,1])",
      "cov(mu[2,1],mu[1,1])",
      "cov(mu[2,1],mu[2,1])",
      "cov(beta[1,1],beta[1,1])",
      "cov(beta[2,1], beta[1,1])",
      "cov(beta[2,1],beta[2,1])",
      "cov(beta[1,2],beta[1,1])",
      "cov(beta[1,2],beta[2,1])",
      "cov(beta[1,2],beta[1,2])",
      "cov(beta[2,2],beta[1,1])",
      "cov(beta[2,2],beta[2,1])",
      "cov(beta[2,2],beta[1,2])",
      "cov(beta[2,2],beta[2,2])"
    )
    raw <- cbind(
      est = c(
        1:11,
        14,
        12,
        15,
        17,
        13,
        16,
        18,
        19
      ),
      se = rep(1, 19),
      `2.5%` = rep(-1, 19),
      `97.5%` = rep(1, 19)
    )
    rownames(raw) <- mplus_names
    aligned <- manMetaVAR:::.SumFitMplusPopulation(
      raw = raw,
      heterogeneity = 2,
      population_object = population_object
    )
    testthat::expect_identical(
      rownames(aligned$raw),
      parameter_names
    )
    testthat::expect_equal(
      unname(aligned$raw[, "est"]),
      seq_len(19)
    )
    testthat::expect_identical(
      aligned$parameter,
      parameter
    )
  }
)

testthat::test_that(
  "Unknown heterogeneity conditions fail explicitly",
  {
    population_object <- list(
      conditions = list(
        list(
          heterogeneity = 1
        )
      )
    )
    testthat::expect_error(
      manMetaVAR:::.SumPopulationCondition(
        heterogeneity = 2,
        population_object = population_object
      ),
      "Could not identify a unique population condition"
    )
  }
)
