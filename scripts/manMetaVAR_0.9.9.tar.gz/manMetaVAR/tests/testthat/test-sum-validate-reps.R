testthat::test_that(
  "Performance summaries require at least two replications",
  {
    testthat::expect_identical(
      manMetaVAR:::.SumValidateReps(2),
      2L
    )
    testthat::expect_error(
      manMetaVAR:::.SumValidateReps(1),
      "at least two"
    )
    testthat::expect_error(
      manMetaVAR:::.SumValidateReps(2.5),
      "at least two"
    )
  }
)
