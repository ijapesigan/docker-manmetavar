testthat::test_that(
  "The k = 2 calibrated population matches parameter-vector ordering",
  {
    utils::data(
      list = c(
        "model",
        "population"
      ),
      package = "manMetaVAR",
      envir = environment()
    )
    testthat::expect_identical(model$k, 2)
    observed_heterogeneity <- vapply(
      X = population$conditions,
      FUN = function(x) {
        x$heterogeneity
      },
      FUN.VALUE = numeric(1)
    )
    testthat::expect_equal(
      unname(sort(observed_heterogeneity)),
      c(0, 1, 2)
    )
    vech <- function(x) {
      x[
        lower.tri(
          x,
          diag = TRUE
        )
      ]
    }
    for (condition in population$conditions) {
      testthat::expect_length(condition$parameter, 19L)
      testthat::expect_false(is.null(names(condition$parameter)))
      testthat::expect_equal(
        anyDuplicated(names(condition$parameter)),
        0L
      )
      testthat::expect_equal(
        unname(condition$parameter[seq_len(6L)]),
        c(
          condition$mu_mu,
          c(condition$beta_mu)
        )
      )
      testthat::expect_equal(
        unname(condition$parameter[7:9]),
        vech(condition$mu_sigma)
      )
      testthat::expect_equal(
        unname(condition$parameter[10:19]),
        vech(condition$beta_sigma)
      )
      testthat::expect_equal(
        condition$nominal_beta_sigma,
        condition$heterogeneity * model$beta_sigma
      )
    }
    zero_condition <- population$conditions[[
      which(observed_heterogeneity == 0)
    ]]
    testthat::expect_equal(
      unname(zero_condition$beta_sigma),
      matrix(0, nrow = 4L, ncol = 4L)
    )
  }
)
