testthat::test_that(
  "Named population values align with a reordered fitted summary",
  {
    parameter <- c(
      "alpha[1,1]" = 0.1,
      "alpha[2,1]" = 0.2,
      "tau_sqr[1,1]" = 0.3
    )
    population_object <- list(
      conditions = list(
        list(
          heterogeneity = 1,
          parameter = parameter
        )
      )
    )
    raw <- cbind(
      est = c(30, 20, 10, 999),
      se = 1
    )
    rownames(raw) <- c(
      "tau_sqr[1,1]",
      "alpha[2,1]",
      "alpha[1,1]",
      "unused"
    )
    aligned <- manMetaVAR:::.SumAlignPopulation(
      raw = raw,
      heterogeneity = 1,
      population_object = population_object
    )
    testthat::expect_identical(
      rownames(aligned$raw),
      names(parameter)
    )
    testthat::expect_equal(
      unname(aligned$raw[, "est"]),
      c(10, 20, 30)
    )
    testthat::expect_identical(
      aligned$parameter,
      parameter
    )
  }
)

testthat::test_that(
  "Missing and duplicated fitted parameter names fail explicitly",
  {
    population_object <- list(
      conditions = list(
        list(
          heterogeneity = 0,
          parameter = c(
            "alpha[1,1]" = 0,
            "alpha[2,1]" = 0
          )
        )
      )
    )
    raw_missing <- cbind(est = 1)
    rownames(raw_missing) <- "alpha[1,1]"
    testthat::expect_error(
      manMetaVAR:::.SumAlignPopulation(
        raw = raw_missing,
        heterogeneity = 0,
        population_object = population_object
      ),
      "were not found"
    )
    raw_duplicated <- cbind(est = c(1, 2))
    rownames(raw_duplicated) <- rep("alpha[1,1]", 2L)
    testthat::expect_error(
      manMetaVAR:::.SumAlignPopulation(
        raw = raw_duplicated,
        heterogeneity = 0,
        population_object = population_object
      ),
      "duplicated"
    )
  }
)
