testthat::test_that(
  "Task parameters are matched by task ID rather than row position",
  {
    params_object <- data.frame(
      taskid = c(3L, 1L, 2L),
      n = c(30L, 10L, 20L),
      time = c(300L, 100L, 200L),
      heterogeneity = c(2, 0, 1)
    )
    observed <- manMetaVAR:::.TaskParameters(
      taskid = 2L,
      params_object = params_object
    )
    testthat::expect_identical(
      observed$taskid,
      2L
    )
    testthat::expect_identical(
      observed$n,
      20L
    )
    testthat::expect_equal(
      observed$heterogeneity,
      1
    )
  }
)

testthat::test_that(
  "Invalid or duplicated task IDs fail explicitly",
  {
    params_object <- data.frame(
      taskid = c(1L, 1L),
      n = c(10L, 20L),
      time = c(100L, 200L),
      heterogeneity = c(0, 1)
    )
    testthat::expect_error(
      manMetaVAR:::.TaskParameters(
        taskid = 1L,
        params_object = params_object
      ),
      "unique parameter row"
    )
    testthat::expect_error(
      manMetaVAR:::.TaskParameters(
        taskid = 0L,
        params_object = params_object
      ),
      "positive integer"
    )
  }
)
