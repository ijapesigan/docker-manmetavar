testthat::test_that(
  "Figure preprocessing keeps heterogeneity and prior conditions distinct",
  {
    design <- expand.grid(
      heterogeneity = c(0, 1, 2),
      method = c(
        "MetaVAR",
        "BMLVAR-Default",
        "BMLVAR-Priors",
        "Naive"
      ),
      stringsAsFactors = FALSE
    )
    design$taskid <- match(
      design$heterogeneity,
      c(0, 1, 2)
    )
    results <- data.frame(
      taskid = design$taskid,
      parnames = "tau_sqr[3,3]",
      parameter = ifelse(design$heterogeneity == 0, 0, 0.1),
      method = design$method,
      n = 50L,
      time = 50L,
      heterogeneity = design$heterogeneity,
      ci = ifelse(design$method == "MetaVAR", "Normal", "Posterior"),
      bias = -0.02,
      rel_bias = ifelse(design$heterogeneity == 0, NA_real_, -0.2),
      coverage = 0.95,
      rmse = 0.1,
      power = 0.8,
      type1_error = ifelse(design$heterogeneity == 0, 0.05, NA_real_)
    )
    observed <- manMetaVAR:::.FigPreprocess(results)
    testthat::expect_identical(
      levels(observed$heterogeneity_label),
      paste0("Heterogeneity = ", 0:2)
    )
    testthat::expect_identical(
      levels(observed$method),
      c(
        "MetaVAR",
        "BMLVAR-Default",
        "BMLVAR-Priors",
        "Uncorr"
      )
    )
    testthat::expect_equal(
      observed$abs_rel_bias[observed$parameter == 0],
      rep(0.02, 4L)
    )
    testthat::expect_equal(
      observed$abs_rel_bias[observed$parameter != 0],
      rep(0.2, 8L)
    )
  }
)

testthat::test_that(
  "Relative bias is undefined for a zero population value",
  {
    testthat::expect_true(
      is.na(
        manMetaVAR:::.SimRelBias(
          thetahat = 0.2,
          theta = 0
        )
      )
    )
  }
)
