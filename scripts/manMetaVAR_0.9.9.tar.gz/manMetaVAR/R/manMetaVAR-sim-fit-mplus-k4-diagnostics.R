#' Simulation Replication - FitMplusK4 Diagnostics
#'
#' @details This function is executed via the `Simk4` function.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return The output is saved as an external file in `output_folder`.
#'
#' @inheritParams Template
#' @export
#' @keywords manMetaVAR fit diagnostics simulation
SimFitMplusK4Diagnostics <- function(taskid,
                                     repid,
                                     output_folder,
                                     seed,
                                     suffix,
                                     overwrite,
                                     integrity) {
  # Do not include default arguments here.
  # Do not run on its own. Use the `Sim` function.
  fn_input <- SimFN(
    output_type = "fit-mplus-k4",
    output_folder = output_folder,
    suffix = suffix
  )
  fn_output <- SimFN(
    output_type = "fit-mplus-k4-diagnostics",
    output_folder = output_folder,
    suffix = suffix
  )
  run <- .SimCheck(
    fn = fn_output,
    overwrite = overwrite,
    integrity = integrity
  )
  if (run) {
    diagnostics <- FitMplusK4Diagnostics(
      object = readRDS(fn_input)
    )
    if (!isTRUE(diagnostics$run$default_priors)) {
      stop(
        paste(
          "The default-prior diagnostics input",
          "was not fit with Mplus default priors."
        ),
        call. = FALSE
      )
    }
    saveRDS(
      object = diagnostics,
      file = fn_output,
      compress = "xz"
    )
    .SimChMod(fn_output)
  }
}
