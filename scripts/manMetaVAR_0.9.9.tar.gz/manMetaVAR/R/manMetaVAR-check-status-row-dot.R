.CheckStatusRow <- function(taskid,
                            repid,
                            output_folder,
                            suffix,
                            output_type,
                            method,
                            stage,
                            k) {
  param <- .TaskParameters(taskid = taskid)
  fn_input <- SimFN(
    output_type = output_type,
    output_folder = output_folder,
    suffix = suffix
  )
  out <- data.frame(
    taskid = as.integer(taskid),
    repid = as.integer(repid),
    k = as.integer(k),
    n = param$n,
    time = param$time,
    heterogeneity = param$heterogeneity,
    output_type = output_type,
    method = method,
    stage = stage,
    exists = file.exists(fn_input),
    readable = FALSE,
    converged = FALSE,
    admissible = FALSE,
    summary_finite = FALSE,
    check_error = FALSE,
    status_code = NA_integer_,
    convergence_prop = NA_real_,
    elapsed_seconds = NA_real_,
    status = "missing_file",
    failure_class = "missing_file",
    message = NA_character_,
    checked_at = format(
      Sys.time(),
      tz = "UTC",
      usetz = TRUE
    ),
    stringsAsFactors = FALSE
  )
  if (!out$exists) {
    return(out)
  }
  object <- tryCatch(
    readRDS(fn_input),
    error = function(e) e
  )
  if (inherits(object, "error")) {
    out$status <- "unreadable_file"
    out$failure_class <- "unreadable_file"
    out$message <- conditionMessage(object)
    return(out)
  }
  out$readable <- TRUE
  out$elapsed_seconds <- .CheckElapsedSeconds(object)
  diagnostic <- tryCatch(
    {
      if (
        output_type %in% c(
          "fit-dt-var-mx",
          "fit-dt-var-mx-k4"
        )
      ) {
        convergence_prop <- converged(
          object$output,
          prop = TRUE
        )
        convergence_prop <- as.numeric(convergence_prop)[1]
        converged_fit <- is.finite(convergence_prop) &&
          convergence_prop >= 1
        list(
          converged = converged_fit,
          admissible = converged_fit,
          summary_finite = NA,
          check_error = FALSE,
          status_code = NA_integer_,
          convergence_prop = convergence_prop,
          message = if (converged_fit) {
            NA_character_
          } else {
            "At least one Stage 1 person-specific model did not converge."
          }
        )
      } else if (
        output_type %in% c(
          "fit-meta-var-mx",
          "fit-meta-var-mx-k4"
        )
      ) {
        status_code <- metaDyn:::.CheckStatusCode(
          model = object$output$output
        )
        converged_fit <- isTRUE(status_code == 0L)
        finite_summary <- if (converged_fit) {
          .CheckFiniteSummary(object)
        } else {
          list(
            ok = FALSE,
            message = paste0(
              "OpenMx/metaDyn status code = ",
              status_code,
              "."
            )
          )
        }
        list(
          converged = converged_fit,
          admissible = converged_fit && finite_summary$ok,
          summary_finite = finite_summary$ok,
          check_error = FALSE,
          status_code = as.integer(status_code),
          convergence_prop = NA_real_,
          message = finite_summary$message
        )
      } else if (output_type == "fit-naive") {
        status_code <- object$output$output$status$code
        converged_fit <- isTRUE(status_code == 0L)
        finite_summary <- if (converged_fit) {
          .CheckFiniteSummary(object)
        } else {
          list(
            ok = FALSE,
            message = paste0(
              "OpenMx status code = ",
              status_code,
              "."
            )
          )
        }
        list(
          converged = converged_fit,
          admissible = converged_fit && finite_summary$ok,
          summary_finite = finite_summary$ok,
          check_error = FALSE,
          status_code = as.integer(status_code),
          convergence_prop = NA_real_,
          message = finite_summary$message
        )
      } else if (
        output_type %in% c(
          "fit-mplus",
          "fit-mplus-priors",
          "fit-mplus-k4",
          "fit-mplus-k4-priors"
        )
      ) {
        normal_termination <- any(
          grepl(
            pattern = "THE MODEL ESTIMATION TERMINATED NORMALLY",
            x = object$output$output,
            fixed = TRUE
          )
        )
        finite_summary <- if (normal_termination) {
          .CheckFiniteSummary(object)
        } else {
          list(
            ok = FALSE,
            message = "Mplus did not report normal termination."
          )
        }
        list(
          converged = normal_termination,
          admissible = normal_termination && finite_summary$ok,
          summary_finite = finite_summary$ok,
          check_error = FALSE,
          status_code = NA_integer_,
          convergence_prop = NA_real_,
          message = finite_summary$message
        )
      } else {
        stop(
          paste0(
            "Unknown simulation output type: ",
            output_type,
            "."
          ),
          call. = FALSE
        )
      }
    },
    error = function(e) {
      list(
        converged = FALSE,
        admissible = FALSE,
        summary_finite = FALSE,
        check_error = TRUE,
        status_code = NA_integer_,
        convergence_prop = NA_real_,
        message = conditionMessage(e)
      )
    }
  )
  out$converged <- diagnostic$converged
  out$admissible <- diagnostic$admissible
  out$summary_finite <- diagnostic$summary_finite
  out$check_error <- isTRUE(diagnostic$check_error)
  out$status_code <- diagnostic$status_code
  out$convergence_prop <- diagnostic$convergence_prop
  out$message <- diagnostic$message
  if (out$check_error) {
    out$status <- "check_error"
    out$failure_class <- "check_error"
  } else if (out$converged && out$admissible) {
    out$status <- "ok"
    out$failure_class <- "ok"
  } else if (!out$converged) {
    out$status <- "nonconvergence"
    out$failure_class <- "nonconvergence"
  } else {
    out$status <- "inadmissible"
    out$failure_class <- "inadmissible"
  }
  out
}
