#' Simulation Results
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @docType data
#' @name results
#' @usage data(results)
#' @format A data frame with one row per design condition, method, interval
#'   type, and parameter:
#'
#' \describe{
#'   \item{taskid}{Simulation task ID.}
#'   \item{replications}{Number of replications.}
#'   \item{parnames}{Parameter name.}
#'   \item{parameter}{Calibrated population parameter value. For transition
#'     parameters under stability rejection, this is the realized truncated
#'     population value rather than the nominal untruncated value.}
#'   \item{method}{Estimation method: MetaVAR, BMLVAR with default priors,
#'     BMLVAR with user-defined priors, or the uncertainty-uncorrected method.}
#'   \item{n}{Number of persons.}
#'   \item{time}{Number of measurement occasions; `NA` denotes the unbalanced
#'     condition.}
#'   \item{heterogeneity}{Transition-parameter heterogeneity multiplier: 0, 1,
#'     or 2.}
#'   \item{ci}{Confidence or credible interval method.}
#'   \item{est}{Mean parameter estimate.}
#'   \item{se}{Mean standard error or posterior standard deviation.}
#'   \item{z}{Mean test statistic when available.}
#'   \item{p}{Mean p-value when available.}
#'   \item{ll}{Mean lower interval limit.}
#'   \item{ul}{Mean upper interval limit.}
#'   \item{sig}{Proportion statistically significant when available.}
#'   \item{zero_hit}{Proportion of intervals containing zero.}
#'   \item{theta_hit}{Proportion of intervals containing the calibrated
#'     population value.}
#'   \item{sq_error}{Mean squared error.}
#'   \item{bias}{Mean estimate minus the calibrated population value.}
#'   \item{rel_bias}{Relative bias for nonzero population values and `NA` when
#'     the population value is zero.}
#'   \item{rmse}{Root mean squared error.}
#'   \item{coverage}{Coverage probability.}
#'   \item{rejection_rate}{Proportion of intervals excluding zero.}
#'   \item{power}{Rejection rate for nonzero population values and `NA` for
#'     zero population values.}
#'   \item{type1_error}{Rejection rate for zero population values and `NA` for
#'     nonzero population values.}
#'   \item{par_idx}{Parameter display index.}
#' }
#'
#' @keywords data results
"results"
