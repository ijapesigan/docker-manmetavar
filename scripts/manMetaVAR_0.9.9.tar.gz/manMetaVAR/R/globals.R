utils::globalVariables(
  c(
    "params",
    "model",
    "population"
  )
)
