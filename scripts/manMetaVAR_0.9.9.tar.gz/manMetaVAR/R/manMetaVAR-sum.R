#' Summary
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param mplus Logical.
#'   If `mplus = TRUE`, summarize the DSEM model.
#' @param metavar_normal Logical.
#'   If `metavar_normal = TRUE`, summarize metaVAR model using
#'   normal confidence intervals.
#' @param metavar_robust Logical.
#'   If `metavar_robust = TRUE`, summarize metaVAR model using
#'   robust (sandwich) confidence intervals.
#' @param naive Logical.
#'   If `naive = TRUE`, summarize naive estimates.
#'
#' @return The output is saved as an external file in `output_folder`.
#'
#' @inheritParams Template
#' @export
#' @keywords manMetaVAR summary simulation
Sum <- function(taskid,
                reps,
                output_folder,
                overwrite,
                integrity,
                naive,
                metavar_normal,
                metavar_robust,
                mplus,
                ncores) {
  .TaskParameters(taskid = taskid)
  reps <- .SumValidateReps(reps)
  output_folder <- file.path(
    output_folder,
    paste0(
      SimProj(),
      "-",
      sprintf("%05d", taskid)
    )
  )
  if (!file.exists(output_folder)) {
    dir.create(
      path = output_folder,
      showWarnings = FALSE,
      recursive = TRUE
    )
    .SimChMod(output_folder)
  }
  if (mplus) {
    SumFitMplus(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
    SumFitMplusDiagnostics(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
    SumFitMplusPriors(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
    SumFitMplusPriorsDiagnostics(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
  if (metavar_normal) {
    SumFitMetaVARNormal(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
  if (metavar_robust) {
    SumFitMetaVARRobust(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
  if (naive) {
    SumFitNaive(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
}
