#' Summary for the Four-Variable Simulation
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param mplus Logical. If `TRUE`, summarize the default- and user-prior
#'   four-variable DSEM fits and their diagnostics.
#' @param metavar_normal Logical. If `TRUE`, summarize the four-variable
#'   metaVAR fits using normal confidence intervals.
#' @param metavar_robust Logical. If `TRUE`, summarize the four-variable
#'   metaVAR fits using robust confidence intervals.
#' @param naive Logical. Retained for consistency with [SimK4()]. The
#'   four-variable simulation does not currently fit a naive model.
#'
#' @return The output is saved as external files in `output_folder`.
#'
#' @inheritParams Template
#' @export
#' @keywords manMetaVAR summary simulation
SumK4 <- function(taskid,
                  reps,
                  output_folder,
                  overwrite,
                  integrity,
                  naive,
                  metavar_normal,
                  metavar_robust,
                  mplus,
                  ncores) {
  .TaskParameters(taskid = taskid)
  reps <- .SumValidateReps(reps)
  output_folder <- file.path(
    output_folder,
    paste0(
      SimProj(),
      "-",
      "k4",
      "-",
      sprintf("%05d", taskid)
    )
  )
  if (!file.exists(output_folder)) {
    dir.create(
      path = output_folder,
      showWarnings = FALSE,
      recursive = TRUE
    )
    .SimChMod(output_folder)
  }
  if (mplus) {
    SumFitMplusK4(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
    SumFitMplusK4Diagnostics(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
    SumFitMplusK4Priors(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
    SumFitMplusK4PriorsDiagnostics(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
  if (metavar_normal) {
    SumFitMetaVARK4Normal(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
  if (metavar_robust) {
    SumFitMetaVARK4Robust(
      taskid,
      reps,
      output_folder,
      overwrite,
      integrity,
      ncores
    )
  }
  if (naive) {
    message("No naive summary for k = 4.")
  }
  .SumDiagnosticsCore(
    taskid = taskid,
    reps = reps,
    output_folder = output_folder,
    overwrite = overwrite,
    integrity = integrity,
    naive = naive,
    metavar = metavar_normal || metavar_robust,
    mplus = mplus,
    variance_tol = 1e-6,
    eigen_tol = 1e-8,
    k4 = TRUE
  )
  invisible(NULL)
}
