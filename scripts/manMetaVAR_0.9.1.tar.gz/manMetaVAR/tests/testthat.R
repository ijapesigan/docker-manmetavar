library(testthat)
library(manMetaVAR)

test_check("manMetaVAR")
