# manMetaVAR 0.9.1

* Initial setup

2025-08-04-14171915