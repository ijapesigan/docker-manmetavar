.FitDTVARRunMultiGroup <- function(data,
                                   observed,
                                   id,
                                   beta,
                                   gamma,
                                   lambda,
                                   kappa,
                                   psi,
                                   theta,
                                   mu0,
                                   sigma0,
                                   covariate,
                                   mu,
                                   sigma,
                                   try,
                                   ncores,
                                   ...) {
  ids <- sort(
    unique(data[, id])
  )
  len_ids <- length(ids)
  on.exit(
    OpenMx::mxOption(
      key = "Number of Threads",
      value = OpenMx::mxOption(
        key = "Number of Threads"
      )
    )
  )
  model <- .FitDTVARModel(
    data = data,
    observed = observed,
    beta = beta,
    gamma = gamma,
    lambda = lambda,
    kappa = kappa,
    psi = psi,
    theta = theta,
    mu0 = mu0,
    sigma0 = sigma0,
    covariate = covariate,
    mu = mu,
    sigma = sigma
  )
  model_id <- function(i,
                       data,
                       id,
                       model) {
    OpenMx::mxModel(
      name = paste0("DTVAR", "_", i),
      model = model,
      OpenMx::mxData(
        observed = data[
          which(
            data[, id] == i
          ), ,
          drop = FALSE
        ],
        type = "raw"
      )
    )
  }
  par <- FALSE
  # nocov start
  if (!is.null(ncores)) {
    ncores <- as.integer(ncores)
    ncores_orig <- ncores
    if (len_ids <= ncores) {
      ncores <- len_ids
    }
    if (ncores > 1) {
      par <- TRUE
    }
  }
  if (len_ids == 1) {
    par <- FALSE
  }
  # nocov end
  if (par) {
    # nocov start
    os_type <- Sys.info()["sysname"]
    if (os_type == "Darwin") {
      fork <- TRUE
    } else if (os_type == "Linux") {
      fork <- TRUE
    } else {
      fork <- FALSE
    }
    foo <- function(ids,
                    data,
                    observed,
                    id,
                    model,
                    ncores) {
      OpenMx::mxOption(
        key = "Number of Threads",
        value = 1
      )
      if (fork) {
        out <- parallel::mclapply(
          X = ids,
          FUN = model_id,
          data = data,
          id = id,
          model = model,
          mc.cores = ncores
        )
      } else {
        cl <- parallel::makeCluster(ncores)
        on.exit(
          parallel::stopCluster(cl = cl)
        )
        out <- parallel::parLapply(
          cl = cl,
          X = ids,
          fun = model_id,
          data = data,
          id = id,
          model = model
        )
      }
      out
    }
    model_i <- foo(
      ids = ids,
      data = data,
      observed = observed,
      id = id,
      model = model,
      ncores = ncores
    )
    OpenMx::mxOption(
      key = "Number of Threads",
      value = ncores_orig
    )
    # nocov end
  } else {
    model_i <- lapply(
      X = ids,
      FUN = model_id,
      data = data,
      id = id,
      model = model
    )
  }
  fit <- OpenMx::mxTryHard(
    model = OpenMx::mxModel(
      name = "DTVAR",
      model_i,
      OpenMx::mxFitFunctionMultigroup(
        paste0(
          "DTVAR",
          "_",
          ids
        )
      )
    ),
    extraTries = try,
    ...
  )
  if (
    (
      fit@output[["status"]][["code"]] > 1
    ) || (
      !isTRUE(fit@output[["infoDefinite"]])
    )
  ) {
    fit <- OpenMx::mxTryHard(
      model = fit,
      extraTries = try,
      ...
    )
  }
  matrices <- OpenMx::omxGetParameters(fit)
  thetahat_vec <- character(0)
  thetahat_vec_names <- character(0)
  if ("beta_vec" %in% matrices) {
    thetahat_vec <- c(
      thetahat_vec,
      "beta_vec"
    )
    beta <- OpenMx::mxEvalByName(
      name = "beta_vec",
      model = fit,
      compute = TRUE
    )
    thetahat_vec_names <- c(
      thetahat_vec_names,
      rownames(beta)
    )
  }
  if ("alpha_vec" %in% matrices) {
    thetahat_vec <- c(
      thetahat_vec,
      "alpha_vec"
    )
    alpha <- OpenMx::mxEvalByName(
      name = "alpha_vec",
      model = fit,
      compute = TRUE
    )
    thetahat_vec_names <- c(
      thetahat_vec_names,
      rownames(alpha)
    )
  }
  if ("psi_vec" %in% matrices) {
    thetahat_vec <- c(
      thetahat_vec,
      "psi_vec"
    )
    psi <- OpenMx::mxEvalByName(
      name = "psi_vec",
      model = fit,
      compute = TRUE
    )
    thetahat_vec_names <- c(
      thetahat_vec_names,
      rownames(psi)
    )
  }
  if ("theta_vec" %in% matrices) {
    thetahat_vec <- c(
      thetahat_vec,
      "theta_vec"
    )
    theta <- OpenMx::mxEvalByName(
      name = "theta_vec",
      model = fit,
      compute = TRUE
    )
    thetahat_vec_names <- c(
      thetahat_vec_names,
      rownames(theta)
    )
  }
  if ("mu0_vec" %in% matrices) {
    thetahat_vec <- c(
      thetahat_vec,
      "mu0_vec"
    )
    mu0 <- OpenMx::mxEvalByName(
      name = "mu0_vec",
      model = fit,
      compute = TRUE
    )
    thetahat_vec_names <- c(
      thetahat_vec_names,
      rownames(mu0)
    )
  }
  if ("sigma0_vec" %in% matrices) {
    thetahat_vec <- c(
      thetahat_vec,
      "sigma0_vec"
    )
    sigma0 <- OpenMx::mxEvalByName(
      name = "sigma0_vec",
      model = fit,
      compute = TRUE
    )
    thetahat_vec_names <- c(
      thetahat_vec_names,
      rownames(sigma0)
    )
  }

  if (length(thetahat_vec) > 0) {
    algString <- sprintf("rbind(%s)", paste(thetahat_vec, collapse = ","))
    algString <- algString[1]
    thetahat <- OpenMx::mxAlgebraFromString(
      algString = algString,
      dimnames = list(
        as.character(thetahat_vec_names),
        "thetahat"
      ),
      name = "thetahat"
    )
    refit <- OpenMx::mxRun(
      OpenMx::mxModel(
        fit,
        thetahat
      ),
      silent = TRUE
    )
  } else {
    refit <- fit
  }
  refit
}
