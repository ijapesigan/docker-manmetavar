.FitDTVARMuFunc <- function(k,
                            statenames) {
  # mu_values will implied by the algebra
  # stable mean
  # alpha is specified as a covariate (gamma)
  list(
    mu_iden = OpenMx::mxMatrix(
      type = "Iden",
      nrow = k,
      ncol = k,
      name = "mu_iden"
    ),
    mu = OpenMx::mxAlgebraFromString(
      algString = "solve(mu_iden - beta) %*% alpha",
      name = "mu",
      dimnames = list(
        statenames,
        "mu"
      )
    )
  )
}
