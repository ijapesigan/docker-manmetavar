#' Fit the First-Order Discrete-Time Vector Autoregressive Model
#'
#' The function uses a multigroup model to fit
#' the first-order discrete-time vector autoregressive model.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @inheritParams FitDTVARIDMx
#' @inherit FitDTVARIDMx details
#'
#' @return Returns an object of class `dtvarmx` which is
#'   a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{List of function arguments.}
#'     \item{fun}{Function used ("FitDTVARMx").}
#'     \item{output}{A fitted OpenMx model.}
#'   }
#'
#' @examples
#' \dontrun{
#' # Generate data using the simStateSpace package------------------------------
#' set.seed(42)
#' sim <- simStateSpace::SimSSMVARFixed(
#'   n = 5,
#'   time = 100,
#'   mu0 = rep(x = 0, times = 3),
#'   sigma0_l = t(chol(diag(3))),
#'   alpha = rep(x = 0, times = 3),
#'   beta = matrix(
#'     data = c(
#'       0.7, 0.5, -0.1,
#'       0.0, 0.6, 0.4,
#'       0, 0, 0.5
#'     ),
#'     nrow = 3
#'   ),
#'   psi_l = t(chol(diag(3)))
#' )
#' data <- as.data.frame(sim)
#'
#' # Fit the model--------------------------------------------------------------
#' library(fitDTVARMx)
#' fit <- FitDTVARMx(
#'   data = data,
#'   observed = c("y1", "y2", "y3"),
#'   id = "id"
#' )
#' print(fit)
#' summary(fit)
#' coef(fit)
#' vcov(fit)
#' }
#'
#' @references
#' Hunter, M. D. (2017).
#' State space modeling in an open source, modular,
#' structural equation modeling environment.
#' *Structural Equation Modeling: A Multidisciplinary Journal*,
#' *25*(2), 307–324.
#' \doi{10.1080/10705511.2017.1369354}
#'
#' Neale, M. C., Hunter, M. D., Pritikin, J. N.,
#' Zahery, M., Brick, T. R., Kirkpatrick, R. M., Estabrook, R.,
#' Bates, T. C., Maes, H. H., & Boker, S. M. (2015).
#' OpenMx 2.0: Extended structural equation and statistical modeling.
#' *Psychometrika*,
#' *81*(2), 535–549.
#' \doi{10.1007/s11336-014-9435-8}
#'
#' @family DTVAR Functions
#' @keywords fitDTVARMx fit
#' @export
FitDTVARMx <- function(data,
                       observed,
                       id,
                       alpha_fixed = FALSE,
                       alpha_free = NULL,
                       alpha_values = NULL,
                       alpha_lbound = NULL,
                       alpha_ubound = NULL,
                       beta_fixed = FALSE,
                       beta_free = NULL,
                       beta_values = NULL,
                       beta_lbound = NULL,
                       beta_ubound = NULL,
                       psi_diag = FALSE,
                       psi_d_free = NULL,
                       psi_d_values = NULL,
                       psi_d_lbound = NULL,
                       psi_d_ubound = NULL,
                       psi_l_free = NULL,
                       psi_l_values = NULL,
                       psi_l_lbound = NULL,
                       psi_l_ubound = NULL,
                       theta_fixed = FALSE,
                       theta_d_free = NULL,
                       theta_d_values = NULL,
                       theta_d_lbound = NULL,
                       theta_d_ubound = NULL,
                       mu0_fixed = TRUE,
                       mu0_func = TRUE,
                       mu0_free = NULL,
                       mu0_values = NULL,
                       mu0_lbound = NULL,
                       mu0_ubound = NULL,
                       sigma0_fixed = TRUE,
                       sigma0_func = TRUE,
                       sigma0_diag = FALSE,
                       sigma0_d_free = NULL,
                       sigma0_d_values = NULL,
                       sigma0_d_lbound = NULL,
                       sigma0_d_ubound = NULL,
                       sigma0_l_free = NULL,
                       sigma0_l_values = NULL,
                       sigma0_l_lbound = NULL,
                       sigma0_l_ubound = NULL,
                       try = 1000,
                       ncores = NULL,
                       ...) {
  byid <- FALSE
  args <- list(
    data = data,
    observed = observed,
    id = id,
    alpha_fixed = alpha_fixed,
    alpha_free = alpha_free,
    alpha_values = alpha_values,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    beta_fixed = beta_fixed,
    beta_free = beta_free,
    beta_values = beta_values,
    beta_lbound = beta_lbound,
    beta_ubound = beta_ubound,
    psi_diag = psi_diag,
    psi_d_free = psi_d_free,
    psi_d_values = psi_d_values,
    psi_d_lbound = psi_d_lbound,
    psi_d_ubound = psi_d_ubound,
    psi_l_free = psi_l_free,
    psi_l_values = psi_l_values,
    psi_l_lbound = psi_l_lbound,
    psi_l_ubound = psi_l_ubound,
    theta_fixed = theta_fixed,
    theta_d_free = theta_d_free,
    theta_d_values = theta_d_values,
    theta_d_lbound = theta_d_lbound,
    theta_d_ubound = theta_d_ubound,
    mu0_fixed = mu0_fixed,
    mu0_func = mu0_func,
    mu0_free = mu0_free,
    mu0_values = mu0_values,
    mu0_lbound = mu0_lbound,
    mu0_ubound = mu0_ubound,
    sigma0_fixed = sigma0_fixed,
    sigma0_func = sigma0_func,
    sigma0_diag = sigma0_diag,
    sigma0_d_free = sigma0_d_free,
    sigma0_d_values = sigma0_d_values,
    sigma0_d_lbound = sigma0_d_lbound,
    sigma0_d_ubound = sigma0_d_ubound,
    sigma0_l_free = sigma0_l_free,
    sigma0_l_values = sigma0_l_values,
    sigma0_l_lbound = sigma0_l_lbound,
    sigma0_l_ubound = sigma0_l_ubound,
    try = try,
    ncores = ncores,
    byid = byid,
    ...
  )
  output <- .FitDTVAR(
    data = data,
    observed = observed,
    id = id,
    alpha_fixed = alpha_fixed,
    alpha_free = alpha_free,
    alpha_values = alpha_values,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    beta_fixed = beta_fixed,
    beta_free = beta_free,
    beta_values = beta_values,
    beta_lbound = beta_lbound,
    beta_ubound = beta_ubound,
    psi_diag = psi_diag,
    psi_d_free = psi_d_free,
    psi_d_values = psi_d_values,
    psi_d_lbound = psi_d_lbound,
    psi_d_ubound = psi_d_ubound,
    psi_l_free = psi_l_free,
    psi_l_values = psi_l_values,
    psi_l_lbound = psi_l_lbound,
    psi_l_ubound = psi_l_ubound,
    theta_fixed = theta_fixed,
    theta_d_free = theta_d_free,
    theta_d_values = theta_d_values,
    theta_d_lbound = theta_d_lbound,
    theta_d_ubound = theta_d_ubound,
    mu0_fixed = mu0_fixed,
    mu0_func = mu0_func,
    mu0_free = mu0_free,
    mu0_values = mu0_values,
    mu0_lbound = mu0_lbound,
    mu0_ubound = mu0_ubound,
    sigma0_fixed = sigma0_fixed,
    sigma0_func = sigma0_func,
    sigma0_diag = sigma0_diag,
    sigma0_d_free = sigma0_d_free,
    sigma0_d_values = sigma0_d_values,
    sigma0_d_lbound = sigma0_d_lbound,
    sigma0_d_ubound = sigma0_d_ubound,
    sigma0_l_free = sigma0_l_free,
    sigma0_l_values = sigma0_l_values,
    sigma0_l_lbound = sigma0_l_lbound,
    sigma0_l_ubound = sigma0_l_ubound,
    try = try,
    ncores = ncores,
    byid = byid,
    ...
  )
  out <- list(
    call = match.call(),
    args = args,
    fun = "FitDTVARMx",
    output = output
  )
  class(out) <- c(
    "dtvarmx",
    class(out)
  )
  out
}
