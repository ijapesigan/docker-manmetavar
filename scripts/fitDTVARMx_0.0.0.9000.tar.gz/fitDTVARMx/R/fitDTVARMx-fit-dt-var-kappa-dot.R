.FitDTVARKappa <- function(k) {
  # D
  # observed variables on covariates
  OpenMx::mxMatrix(
    type = "Zero",
    nrow = k,
    ncol = 1,
    name = "kappa"
  )
}
