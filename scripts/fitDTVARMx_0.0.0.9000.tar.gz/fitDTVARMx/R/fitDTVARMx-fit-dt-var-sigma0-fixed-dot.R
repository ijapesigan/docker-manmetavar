.FitDTVARSigma0Fixed <- function(k,
                                 statenames,
                                 sigma0_diag,
                                 sigma0_d_values,
                                 sigma0_l_values) {
  # P0
  # Initial condition covariance matrix
  if (sigma0_diag) {
    out <- .FitDTVARSigma0FixedDiag(
      k = k,
      statenames = statenames,
      sigma0_d_values = sigma0_d_values
    )
  } else {
    out <- .FitDTVARSigma0FixedSym(
      k = k,
      statenames = statenames,
      sigma0_d_values = sigma0_d_values,
      sigma0_l_values = sigma0_l_values
    )
  }
  out
}
