.FitDTVARMu0Func <- function(k,
                             statenames) {
  # x0
  # initial condition
  # mean
  # alpha is specified as a covariate (gamma)
  # mu0_values will implied by the algebra
  list(
    mu0_iden = OpenMx::mxMatrix(
      type = "Iden",
      nrow = k,
      ncol = k,
      name = "mu0_iden"
    ),
    mu0 = OpenMx::mxAlgebraFromString(
      algString = "solve(mu0_iden - beta) %*% alpha",
      name = "mu0",
      dimnames = list(
        statenames,
        "mu0"
      )
    ),
    mu0_vec = OpenMx::mxAlgebraFromString(
      algString = "cvectorize(mu0)",
      name = "mu0_vec",
      dimnames = list(
        statenames,
        "mu0_vec"
      )
    )
  )
}
