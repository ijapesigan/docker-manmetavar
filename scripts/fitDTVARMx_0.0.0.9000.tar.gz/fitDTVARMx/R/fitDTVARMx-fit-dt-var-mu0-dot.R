.FitDTVARMu0 <- function(k,
                         statenames,
                         mu0_fixed,
                         mu0_func,
                         mu0_free,
                         mu0_values,
                         mu0_lbound,
                         mu0_ubound) {
  # x0
  # initial condition
  # mean
  if (mu0_fixed) {
    if (mu0_func) {
      out <- .FitDTVARMu0Func(
        k = k,
        statenames = statenames
      )
    } else {
      out <- .FitDTVARMu0Fixed(
        k = k,
        statenames = statenames,
        mu0_values = mu0_values
      )
    }
  } else {
    out <- .FitDTVARMu0Vec(
      k = k,
      statenames = statenames,
      mu0_free = mu0_free,
      mu0_values = mu0_values,
      mu0_lbound = mu0_lbound,
      mu0_ubound = mu0_ubound
    )
  }
  out
}
