.FitDTVARTheta <- function(k,
                           idx,
                           observed,
                           theta_fixed = TRUE,
                           theta_values = NULL,
                           theta_free = NULL,
                           theta_lbound = NULL,
                           theta_ubound = NULL) {
  # R
  # measurement error
  if (theta_fixed) {
    out <- .FitDTVARThetaFixed(
      k = k,
      observed = observed
    )
  } else {
    out <- .FitDTVARThetaDiag(
      k = k,
      idx = idx,
      observed = observed,
      theta_values = theta_values,
      theta_free = theta_free,
      theta_lbound = theta_lbound,
      theta_ubound = theta_ubound
    )
  }
  out
}
