.FitDTVARTheta <- function(k,
                           observed,
                           theta_fixed,
                           theta_d_free,
                           theta_d_values,
                           theta_d_lbound,
                           theta_d_ubound) {
  # R
  # measurement error
  if (theta_fixed) {
    out <- .FitDTVARThetaFixed(
      k = k,
      observed = observed
    )
  } else {
    out <- .FitDTVARThetaLDiag(
      k = k,
      observed = observed,
      theta_d_free = theta_d_free,
      theta_d_values = theta_d_values,
      theta_d_lbound = theta_d_lbound,
      theta_d_ubound = theta_d_ubound
    )
  }
  out
}
