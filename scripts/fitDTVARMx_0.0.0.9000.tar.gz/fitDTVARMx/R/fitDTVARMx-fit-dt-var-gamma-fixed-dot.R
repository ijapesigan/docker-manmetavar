.FitDTVARGammaFixed <- function(k,
                                alpha_values) {
  # B
  # latent variables on covariates
  if (is.null(alpha_values)) {
    out <- OpenMx::mxMatrix(
      type = "Zero",
      nrow = k,
      ncol = 1,
      name = "alpha"
    )
  } else {
    out <- OpenMx::mxMatrix(
      type = "Full",
      nrow = k,
      ncol = 1,
      free = FALSE,
      values = alpha_values,
      byrow = FALSE,
      name = "alpha"
    )
  }
  out
}
