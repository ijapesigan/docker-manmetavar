.FitDTVARSigma0Func <- function(k,
                                statenames) {
  # P0
  # Initial condition covariance matrix
  # sigma0_values will be implied by the algebra
  list(
    J = OpenMx::mxMatrix(
      type = "Iden",
      nrow = k * k,
      ncol = k * k,
      name = "J"
    ),
    sigma0_vector = OpenMx::mxAlgebraFromString(
      algString = "solve(J - beta %x% beta) %*% cvectorize(psi)",
      name = "sigma0_vector"
    ),
    sigma0_mat = OpenMx::mxMatrix(
      "Full",
      nrow = k,
      ncol = k,
      labels = paste0(
        "sigma0_vector[",
        1:(k * k),
        ",",
        1,
        "]"
      ),
      dimnames = list(
        statenames,
        statenames
      ),
      name = "sigma0_mat"
    ),
    sigma0 = OpenMx::mxAlgebraFromString(
      algString = "0.5 * (sigma0_mat + t(sigma0_mat))",
      dimnames = list(
        statenames,
        statenames
      ),
      name = "sigma0"
    )
  )
}
