.FitDTVARRunID <- function(data,
                           observed,
                           id,
                           beta,
                           gamma,
                           lambda,
                           kappa,
                           psi,
                           theta,
                           mu0,
                           sigma0,
                           covariate,
                           mu,
                           sigma,
                           try,
                           ncores,
                           path,
                           prefix,
                           clean,
                           ...) {
  ids <- sort(
    unique(data[, id])
  )
  len_ids <- length(ids)
  on.exit(
    OpenMx::mxOption(
      key = "Number of Threads",
      value = OpenMx::mxOption(
        key = "Number of Threads"
      )
    )
  )
  model <- .FitDTVARModel(
    data = data,
    observed = observed,
    beta = beta,
    gamma = gamma,
    lambda = lambda,
    kappa = kappa,
    psi = psi,
    theta = theta,
    mu0 = mu0,
    sigma0 = sigma0,
    covariate = covariate,
    mu = mu,
    sigma = sigma
  )
  fit <- function(i,
                  data,
                  id,
                  model,
                  try,
                  path,
                  prefix) {
    fn <- file.path(
      path,
      paste0(
        prefix,
        "_",
        "id",
        "_",
        i,
        ".Rds"
      )
    )
    run <- function(i,
                    data,
                    id,
                    model,
                    try,
                    path,
                    prefix) {
      out <- OpenMx::mxTryHard(
        model = OpenMx::mxModel(
          model = model,
          OpenMx::mxData(
            observed = data[
              which(
                data[, id] == i
              ), ,
              drop = FALSE
            ],
            type = "raw"
          )
        ),
        extraTries = try,
        ...
      )
      if (
        (
          out@output[["status"]][["code"]] > 1
        ) || (
          !isTRUE(out@output[["infoDefinite"]])
        )
      ) {
        out <- OpenMx::mxTryHard(
          model = out,
          extraTries = try,
          ...
        )
        if (out@output[["status"]][["code"]] > 1) {
          message(
            paste0(
              "Exit code for ",
              "ID = ",
              i,
              " is ",
              out@output[["status"]][["code"]],
              ".\n"
            )
          )
        }
        if (!isTRUE(out@output[["infoDefinite"]])) {
          message(
            paste0(
              "Hessian for ",
              "ID = ",
              i,
              " is not positive-definite.",
              ".\n"
            )
          )
        }
      }
      matrices <- OpenMx::omxGetParameters(out)
      thetahat_vec <- character(0)
      thetahat_vec_names <- character(0)
      if ("beta_vec" %in% matrices) {
        thetahat_vec <- c(
          thetahat_vec,
          "beta_vec"
        )
        beta <- OpenMx::mxEvalByName(
          name = "beta_vec",
          model = out,
          compute = TRUE
        )
        thetahat_vec_names <- c(
          thetahat_vec_names,
          rownames(beta)
        )
      }
      if ("alpha_vec" %in% matrices) {
        thetahat_vec <- c(
          thetahat_vec,
          "alpha_vec"
        )
        alpha <- OpenMx::mxEvalByName(
          name = "alpha_vec",
          model = out,
          compute = TRUE
        )
        thetahat_vec_names <- c(
          thetahat_vec_names,
          rownames(alpha)
        )
      }
      if ("psi_vec" %in% matrices) {
        thetahat_vec <- c(
          thetahat_vec,
          "psi_vec"
        )
        psi <- OpenMx::mxEvalByName(
          name = "psi_vec",
          model = out,
          compute = TRUE
        )
        thetahat_vec_names <- c(
          thetahat_vec_names,
          rownames(psi)
        )
      }
      if ("theta_vec" %in% matrices) {
        thetahat_vec <- c(
          thetahat_vec,
          "theta_vec"
        )
        theta <- OpenMx::mxEvalByName(
          name = "theta_vec",
          model = out,
          compute = TRUE
        )
        thetahat_vec_names <- c(
          thetahat_vec_names,
          rownames(theta)
        )
      }
      if ("mu0_vec" %in% matrices) {
        thetahat_vec <- c(
          thetahat_vec,
          "mu0_vec"
        )
        mu0 <- OpenMx::mxEvalByName(
          name = "mu0_vec",
          model = out,
          compute = TRUE
        )
        thetahat_vec_names <- c(
          thetahat_vec_names,
          rownames(mu0)
        )
      }
      if ("sigma0_vec" %in% matrices) {
        thetahat_vec <- c(
          thetahat_vec,
          "sigma0_vec"
        )
        sigma0 <- OpenMx::mxEvalByName(
          name = "sigma0_vec",
          model = out,
          compute = TRUE
        )
        thetahat_vec_names <- c(
          thetahat_vec_names,
          rownames(sigma0)
        )
      }
      if (length(thetahat_vec) > 0) {
        algString <- sprintf("rbind(%s)", paste(thetahat_vec, collapse = ","))
        algString <- algString[1]
        thetahat <- OpenMx::mxAlgebraFromString(
          algString = algString,
          dimnames = list(
            as.character(thetahat_vec_names),
            "thetahat"
          ),
          name = "thetahat"
        )
        refit <- OpenMx::mxRun(
          OpenMx::mxModel(
            out,
            thetahat
          ),
          silent = TRUE
        )
      } else {
        refit <- out
      }
      saveRDS(
        object = refit,
        file = fn
      )
      refit
    }
    tryCatch(
      {
        if (file.exists(fn)) {
          readRDS(
            file = fn
          )
        } else {
          run(
            i = i,
            data = data,
            id = id,
            model = model,
            try = try,
            path = path,
            prefix = prefix
          )
        }
      },
      error = function(e) {
        run(
          i = i,
          data = data,
          id = id,
          model = model,
          try = try,
          path = path,
          prefix = prefix
        )
      }
    )
  }
  par <- FALSE
  # nocov start
  if (!is.null(ncores)) {
    ncores <- as.integer(ncores)
    if (len_ids <= ncores) {
      ncores <- len_ids
    }
    if (ncores > 1) {
      par <- TRUE
    }
  }
  if (len_ids == 1) {
    par <- FALSE
  }
  # nocov end
  if (par) {
    # nocov start
    os_type <- Sys.info()["sysname"]
    if (os_type == "Darwin") {
      fork <- TRUE
    } else if (os_type == "Linux") {
      fork <- TRUE
    } else {
      fork <- FALSE
    }
    foo <- function(ids,
                    data,
                    observed,
                    id,
                    beta,
                    gamma,
                    lambda,
                    kappa,
                    psi,
                    theta,
                    mu0,
                    sigma0,
                    covariate,
                    mu,
                    sigma,
                    ncores,
                    path,
                    prefix) {
      OpenMx::mxOption(
        key = "Number of Threads",
        value = 1
      )
      if (fork) {
        out <- parallel::mclapply(
          X = ids,
          FUN = fit,
          data = data,
          id = id,
          model = model,
          try = try,
          path = path,
          prefix = prefix,
          mc.cores = ncores
        )
      } else {
        cl <- parallel::makeCluster(ncores)
        on.exit(
          parallel::stopCluster(cl = cl)
        )
        out <- parallel::parLapply(
          cl = cl,
          X = ids,
          fun = fit,
          data = data,
          id = id,
          model = model,
          try = try
        )
      }
      out
    }
    output <- foo(
      ids = ids,
      data = data,
      observed = observed,
      id = id,
      beta = beta,
      gamma = gamma,
      lambda = lambda,
      kappa = kappa,
      psi = psi,
      theta = theta,
      mu0 = mu0,
      sigma0 = sigma0,
      covariate = covariate,
      mu = mu,
      sigma = sigma,
      ncores = ncores,
      path = path,
      prefix = prefix
    )
    # nocov end
  } else {
    output <- lapply(
      X = ids,
      FUN = fit,
      data = data,
      id = id,
      model = model,
      try = try
    )
  }
  if (clean) {
    unlink(
      file.path(
        path,
        paste0(
          prefix,
          "*.Rds"
        )
      )
    )
  }
  output
}
