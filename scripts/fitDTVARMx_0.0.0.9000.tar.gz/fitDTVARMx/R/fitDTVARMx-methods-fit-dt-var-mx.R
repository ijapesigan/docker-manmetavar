#' Print Method for Object of Class `dtvarmx`
#'
#' @author Ivan Jacob Agaloos Pesigan
#' @param x an object of class `dtvarmx`.
#' @param ... further arguments.
#'
#' @method print dtvarmx
#' @keywords methods
#' @export
print.dtvarmx <- function(x,
                          ...) {
  base::print(
    summary(x$output)
  )
}

#' Summary Method for Object of Class `dtvarmx`
#'
#' @author Ivan Jacob Agaloos Pesigan
#' @param object an object of class `dtvarmx`.
#' @param ... further arguments.
#'
#' @method summary dtvarmx
#' @keywords methods
#' @export
summary.dtvarmx <- function(object,
                            ...) {
  summary(object$output)
}

#' Parameter Estimates
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param object Object of class `dtvarmx`.
#' @param alpha Logical.
#'   If `alpha = TRUE`,
#'   include estimates of the `alpha` vector, if available.
#'   If `alpha = FALSE`,
#'   exclude estimates of the `alpha` vector.
#' @param psi Logical.
#'   If `psi = TRUE`,
#'   include estimates of the `psi` matrix, if available.
#'   If `psi = FALSE`,
#'   exclude estimates of the `psi` matrix.
#' @param theta Logical.
#'   If `theta = TRUE`,
#'   include estimates of the `theta` matrix, if available.
#'   If `theta = FALSE`,
#'   exclude estimates of the `theta` matrix.
#' @param ... additional arguments.
#' @return Returns a vector of parameter estimates.
#'
#' @method coef dtvarmx
#' @keywords methods
#' @export
coef.dtvarmx <- function(object,
                         alpha = TRUE,
                         psi = TRUE,
                         theta = TRUE,
                         ...) {
  thetahat <- OpenMx::mxEvalByName(
    name = "thetahat",
    model = object$output,
    compute = TRUE
  )
  parnames <- rownames(thetahat)
  coefs <- c(thetahat)
  names(coefs) <- parnames
  idx <- grep(
    pattern = "^beta\\[",
    x = parnames
  )
  if (alpha) {
    idx <- c(
      idx,
      grep(
        pattern = "^alpha\\[",
        x = parnames
      )
    )
  }
  if (psi) {
    idx <- c(
      idx,
      grep(
        pattern = "^psi\\[",
        x = parnames
      )
    )
  }
  if (theta) {
    idx <- c(
      idx,
      grep(
        pattern = "^theta\\[",
        x = parnames
      )
    )
  }
  coefs[idx]
}

#' Sampling Covariance Matrix of the Parameter Estimates
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param object Object of class `dtvarmx`.
#' @param alpha Logical.
#'   If `alpha = TRUE`,
#'   include estimates of the `alpha` vector, if available.
#'   If `alpha = FALSE`,
#'   exclude estimates of the `alpha` vector.
#' @param psi Logical.
#'   If `psi = TRUE`,
#'   include estimates of the `psi` matrix, if available.
#'   If `psi = FALSE`,
#'   exclude estimates of the `psi` matrix.
#' @param theta Logical.
#'   If `theta = TRUE`,
#'   include estimates of the `theta` matrix, if available.
#'   If `theta = FALSE`,
#'   exclude estimates of the `theta` matrix.
#' @param ... additional arguments.
#' @return Returns a list of sampling variance-covariance matrices.
#'
#' @method vcov dtvarmx
#' @keywords methods
#' @export
vcov.dtvarmx <- function(object,
                         alpha = TRUE,
                         psi = TRUE,
                         theta = TRUE,
                         ...) {
  thetahat <- OpenMx::mxEvalByName(
    name = "thetahat",
    model = object$output,
    compute = TRUE
  )
  parnames <- rownames(thetahat)
  vcovs <- OpenMx::mxSE(
    x = "thetahat",
    model = object$output,
    details = TRUE
  )$Cov
  rownames(vcovs) <- colnames(vcovs) <- parnames
  idx <- grep(
    pattern = "^beta\\[",
    x = parnames
  )
  if (alpha) {
    idx <- c(
      idx,
      grep(
        pattern = "^alpha\\[",
        x = parnames
      )
    )
  }
  if (psi) {
    idx <- c(
      idx,
      grep(
        pattern = "^psi\\[",
        x = parnames
      )
    )
  }
  if (theta) {
    idx <- c(
      idx,
      grep(
        pattern = "^theta\\[",
        x = parnames
      )
    )
  }
  vcovs[idx, idx, drop = FALSE]
}
