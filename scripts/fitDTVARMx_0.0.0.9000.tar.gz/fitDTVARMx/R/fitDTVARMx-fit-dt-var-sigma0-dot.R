.FitDTVARSigma0 <- function(k,
                            statenames,
                            sigma0_fixed,
                            sigma0_func,
                            sigma0_diag,
                            sigma0_d_free,
                            sigma0_d_values,
                            sigma0_d_lbound,
                            sigma0_d_ubound,
                            sigma0_l_free,
                            sigma0_l_values,
                            sigma0_l_lbound,
                            sigma0_l_ubound) {
  # P0
  # Initial condition covariance matrix
  if (sigma0_fixed) {
    if (sigma0_func) {
      out <- .FitDTVARSigma0Func(
        k = k,
        statenames = statenames
      )
    } else {
      out <- .FitDTVARSigma0Fixed(
        k = k,
        statenames = statenames,
        sigma0_diag = sigma0_diag,
        sigma0_d_values = sigma0_d_values,
        sigma0_l_values = sigma0_l_values
      )
    }
  } else {
    if (sigma0_diag) {
      out <- .FitDTVARSigma0LDiag(
        k = k,
        statenames = statenames,
        sigma0_d_free = sigma0_d_free,
        sigma0_d_values = sigma0_d_values,
        sigma0_d_lbound = sigma0_d_lbound,
        sigma0_d_ubound = sigma0_d_ubound
      )
    } else {
      out <- .FitDTVARSigma0LSym(
        k = k,
        statenames = statenames,
        sigma0_d_free = sigma0_d_free,
        sigma0_d_values = sigma0_d_values,
        sigma0_d_lbound = sigma0_d_lbound,
        sigma0_d_ubound = sigma0_d_ubound,
        sigma0_l_free = sigma0_l_free,
        sigma0_l_values = sigma0_l_values,
        sigma0_l_lbound = sigma0_l_lbound,
        sigma0_l_ubound = sigma0_l_ubound
      )
    }
  }
  out
}
