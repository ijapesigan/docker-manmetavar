#' Fit the First-Order Discrete-Time Vector Autoregressive Model by ID
#'
#' The function fits
#' the first-order discrete-time vector autoregressive model
#' for each unit ID.
#'
#' @details The measurement model is given by
#' \deqn{
#'   \mathbf{y}_{i, t}
#'   =
#'   \boldsymbol{\Lambda}
#'   \boldsymbol{\eta}_{i, t}
#'   +
#'   \boldsymbol{\varepsilon}_{i, t},
#'   \quad
#'   \mathrm{with}
#'   \quad
#'   \boldsymbol{\varepsilon}_{i, t}
#'   \sim
#'   \mathcal{N}
#'   \left(
#'   \mathbf{0},
#'   \boldsymbol{\Theta}
#'   \right)
#' }
#' where
#' \eqn{\mathbf{y}_{i, t}},
#' \eqn{\boldsymbol{\eta}_{i, t}},
#' and
#' \eqn{\boldsymbol{\varepsilon}_{i, t}}
#' are random variables
#' and
#' \eqn{\boldsymbol{\Lambda}},
#' and
#' \eqn{\boldsymbol{\Theta}}
#' are model parameters.
#' \eqn{\mathbf{y}_{i, t}}
#' represents a vector of observed random variables,
#' \eqn{\boldsymbol{\eta}_{i, t}}
#' a vector of latent random variables,
#' and
#' \eqn{\boldsymbol{\varepsilon}_{i, t}}
#' a vector of random measurement errors,
#' at time \eqn{t} and individual \eqn{i}.
#' \eqn{\boldsymbol{\Lambda}}
#' denotes a matrix of factor loadings,
#' and
#' \eqn{\boldsymbol{\Theta}}
#' the covariance matrix of
#' \eqn{\boldsymbol{\varepsilon}}.
#' In this model,
#' \eqn{\boldsymbol{\Lambda}} is an identity matrix and
#' \eqn{\boldsymbol{\Theta}} is a diagonal matrix.
#'
#' The dynamic structure is given by
#' \deqn{
#'   \boldsymbol{\eta}_{i, t}
#'   =
#'   \boldsymbol{\alpha}
#'   +
#'   \boldsymbol{\beta}
#'   \boldsymbol{\eta}_{i, t - 1}
#'   +
#'   \boldsymbol{\zeta}_{i, t},
#'   \quad
#'   \mathrm{with}
#'   \quad
#'   \boldsymbol{\zeta}_{i, t}
#'   \sim
#'   \mathcal{N}
#'   \left(
#'   \mathbf{0},
#'   \boldsymbol{\Psi}
#'   \right)
#' }
#' where
#' \eqn{\boldsymbol{\eta}_{i, t}},
#' \eqn{\boldsymbol{\eta}_{i, t - 1}},
#' and
#' \eqn{\boldsymbol{\zeta}_{i, t}}
#' are random variables,
#' and
#' \eqn{\boldsymbol{\alpha}},
#' \eqn{\boldsymbol{\beta}},
#' and
#' \eqn{\boldsymbol{\Psi}}
#' are model parameters.
#' Here,
#' \eqn{\boldsymbol{\eta}_{i, t}}
#' is a vector of latent variables
#' at time \eqn{t} and individual \eqn{i},
#' \eqn{\boldsymbol{\eta}_{i, t - 1}}
#' represents a vector of latent variables
#' at time \eqn{t - 1} and individual \eqn{i},
#' and
#' \eqn{\boldsymbol{\zeta}_{i, t}}
#' represents a vector of dynamic noise
#' at time \eqn{t} and individual \eqn{i}.
#' \eqn{\boldsymbol{\alpha}}
#' denotes a vector of intercepts,
#' \eqn{\boldsymbol{\beta}}
#' a matrix of autoregression
#' and cross regression coefficients,
#' and
#' \eqn{\boldsymbol{\Psi}}
#' the covariance matrix of
#' \eqn{\boldsymbol{\zeta}_{i, t}}.
#'
#' Covariances such as \eqn{\boldsymbol{\Psi}}
#' and \eqn{\boldsymbol{\Theta}}
#' are estimated using the LDL′ decomposition
#' of a positive definite covariance matrix.
#' See [LDL()] for more details.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param data Data frame.
#'   A data frame object of data for potentially
#'   multiple subjects that contain
#'   a column of subject ID numbers
#'   (i.e., an ID variable), and
#'   at least one column of observed values.
#' @param observed Character vector.
#'   A vector of character strings
#'   of the names of the observed variables in the data.
#' @param id Character string.
#'   A character string of the name of the ID variable in the data.
#' @param alpha_fixed Logical.
#'   If `TRUE`, the dynamic model intercept vector `alpha` is fixed.
#'   If `FALSE`, `alpha` is estimated.
#' @param alpha_free Logical vector indicating which elements of `alpha`
#'   are freely estimated. If `NULL`, all elements are free.
#'   Ignored if `alpha_fixed = TRUE`.
#' @param alpha_values Numeric vector of values for `alpha`.
#'   If `alpha_fixed = TRUE`, these are fixed values.
#'   If `alpha_fixed = FALSE`, these are starting values.
#'   If `NULL`, defaults to a vector of zeros.
#' @param alpha_lbound Numeric vector of lower bounds for `alpha`.
#'   If `NULL`, no lower bounds are set.
#'   Ignored if `alpha_fixed = TRUE`.
#' @param alpha_ubound Numeric vector of upper bounds for `alpha`.
#'   If `NULL`, no upper bounds are set.
#'   Ignored if `alpha_fixed = TRUE`.
#' @param beta_fixed Logical.
#'   If `TRUE`, the dynamic model coefficient matrix `beta` is fixed.
#'   If `FALSE`, `beta` is estimated.
#' @param beta_free Logical matrix indicating which elements of `beta`
#'   are freely estimated. If `NULL`, all elements are free.
#'   Ignored if `beta_fixed = TRUE`.
#' @param beta_values Numeric matrix of values for `beta`.
#'   If `beta_fixed = TRUE`, these are fixed values.
#'   If `beta_fixed = FALSE`, these are starting values.
#'   If `NULL`, defaults to a zero matrix.
#' @param beta_lbound Numeric matrix of lower bounds for `beta`.
#'   If `NULL`, defaults to -1.5.
#'   Ignored if `beta_fixed = TRUE`.
#' @param beta_ubound Numeric matrix of upper bounds for `beta`.
#'   If `NULL`, defaults to +1.5.
#'   Ignored if `beta_fixed = TRUE`.
#' @param psi_diag Logical.
#'   If `TRUE`, `psi` is diagonal.
#'   If `FALSE`, `psi` is symmetric.
#' @param psi_d_free Logical vector
#'   indicating free/fixed status of the elements of `psi_d`.
#'   If `NULL`, all element of `psi_d` are free.
#' @param psi_d_values Numeric vector
#'   with starting values for `psi_d`.
#'   If `NULL`, defaults to a vector of ones.
#' @param psi_d_lbound Numeric vector
#'   with lower bounds for `psi_d`.
#'   If `NULL`, no lower bounds are set.
#' @param psi_d_ubound Numeric vector
#'   with upper bounds for `psi_d`.
#'   If `NULL`, no upper bounds are set.
#' @param psi_l_free Logical matrix
#'   indicating which strictly-lower-triangular elements of `psi_l` are free.
#'   Ignored if `psi_diag = TRUE`.
#' @param psi_l_values Numeric matrix
#'   of starting values for the strictly-lower-triangular elements of `psi_l`.
#'   If `NULL`, defaults to a null matrix.
#' @param psi_l_lbound Numeric matrix
#'   with lower bounds for `psi_l`.
#'   If `NULL`, no lower bounds are set.
#' @param psi_l_ubound Numeric matrix
#'   with upper bounds for `psi_l`.
#'   If `NULL`, no upper bounds are set.
#' @param theta_fixed Logical.
#'   If `TRUE`, the measurement error matrix `theta`
#'   is fixed to the null matrix.
#'   If `FALSE`, only diagonal elements are estimated
#'   (off-diagonals fixed to zero).
#' @param theta_d_free Logical vector
#'   indicating free/fixed status of the diagonal parameters `theta_d`.
#'   If `NULL`, all element of `theta_d` are free.
#' @param theta_d_values Numeric vector
#'   with starting values for `theta_d`.
#'   If `theta_fixed = TRUE`, these are fixed values.
#'   If `theta_fixed = FALSE`, these are starting values.
#'   If `NULL`, defaults to an identity matrix.
#' @param theta_d_lbound Numeric vector
#'   with lower bounds for `theta_d`.
#'   If `NULL`, no lower bounds are set.
#' @param theta_d_ubound Numeric vector
#'   with upper bounds for `theta_d`.
#'   If `NULL`, no upper bounds are set.
#' @param mu0_fixed Logical.
#'   If `TRUE`, the initial mean vector `mu0` is fixed.
#'   If `FALSE`, `mu0` is estimated.
#' @param mu0_func Logical.
#'   If `TRUE` and `mu0_fixed = TRUE`, `mu0` is fixed to
#'   \eqn{ (I - \beta)^{-1} \alpha }.
#' @param mu0_free Logical vector indicating which elements of `mu0`
#'   are freely estimated.
#' @param mu0_values Numeric vector of values for `mu0`.
#'   If `mu0_fixed = TRUE`, these are fixed values.
#'   If `mu0_fixed = FALSE`, these are starting values.
#'   If `NULL`, defaults to a vector of zeros.
#' @param mu0_lbound Numeric vector of lower bounds for `mu0`.
#'   If `NULL`, no lower bounds are set.
#'   Ignored if `mu0_fixed = TRUE`.
#' @param mu0_ubound Numeric vector of upper bounds for `mu0`.
#'   If `NULL`, no upper bounds are set.
#'   Ignored if `mu0_fixed = TRUE`.
#' @param sigma0_fixed Logical.
#'   If `TRUE`, the initial covariance matrix `sigma0` is fixed.
#'   If `FALSE`, `sigma0` is estimated.
#' @param sigma0_func Logical.
#'   If `TRUE` and `sigma0_fixed = TRUE`, `sigma0` is fixed to
#'   \eqn{ (I - \beta \otimes \beta)^{-1} \mathrm{Vec}(\Psi) }.
#' @param sigma0_diag Logical.
#'   If `TRUE`, `sigma0` is diagonal.
#'   If `FALSE`, `sigma0` is symmetric.
#' @param sigma0_d_free Logical vector
#'   indicating free/fixed status of the elements of `sigma0_d`.
#'   If `NULL`, all element of `sigma0_d` are free.
#' @param sigma0_d_values Numeric vector
#'   with starting values for `sigma0_d`.
#'   If `NULL`, defaults to a vector of ones.
#' @param sigma0_d_lbound Numeric vector
#'   with lower bounds for `sigma0_d`.
#'   If `NULL`, no lower bounds are set.
#' @param sigma0_d_ubound Numeric vector
#'   with upper bounds for `sigma0_d`.
#'   If `NULL`, no upper bounds are set.
#' @param sigma0_l_free Logical matrix
#'   indicating which
#'   strictly-lower-triangular elements of `sigma0_l` are free.
#'   Ignored if `sigma0_diag = TRUE`.
#' @param sigma0_l_values Numeric matrix
#'   of starting values
#'   for the strictly-lower-triangular elements of `sigma0_l`.
#'   If `NULL`, defaults to a null matrix.
#' @param sigma0_l_lbound Numeric matrix
#'   with lower bounds for `sigma0_l`.
#'   If `NULL`, no lower bounds are set.
#' @param sigma0_l_ubound Numeric matrix
#'   with upper bounds for `sigma0_l`.
#'   If `NULL`, no upper bounds are set.
#' @param try Positive integer.
#'   Number of extra optimization tries.
#' @param ncores Positive integer.
#'   Number of cores to use.
#' @param path Path to a directory
#'   to store estimates by `ID`.
#' @param prefix Character string.
#'   Prefix used for the file names
#'   for the estimates by `ID`.
#' @param clean Logical.
#'   If `clean = TRUE`,
#'   delete intermediate files generated by the function.
#' @param ... Additional optional arguments to pass to `mxTryHard`.
#'
#' @return Returns an object of class `dtvaridmx` which is
#'   a list with the following elements:
#'   \describe{
#'     \item{call}{Function call.}
#'     \item{args}{List of function arguments.}
#'     \item{fun}{Function used ("FitDTVARIDMx").}
#'     \item{output}{A list of fitted OpenMx models.}
#'   }
#'
#' @examples
#' \dontrun{
#' # Generate data using the simStateSpace package------------------------------
#' set.seed(42)
#' beta_mu <- matrix(
#'   data = c(
#'     0.7, 0.5, -0.1,
#'     0.0, 0.6, 0.4,
#'     0, 0, 0.5
#'   ),
#'   nrow = 3
#' )
#' beta_sigma <- diag(3 * 3)
#' beta <- simStateSpace::SimBetaN(
#'   n = 5,
#'   beta = beta_mu,
#'   vcov_beta_vec_l = t(chol(beta_sigma))
#' )
#' sim <- simStateSpace::SimSSMVARIVary(
#'   n = 5,
#'   time = 100,
#'   mu0 = list(rep(x = 0, times = 3)),
#'   sigma0_l = list(t(chol(diag(3)))),
#'   alpha = list(rep(x = 0, times = 3)),
#'   beta = beta,
#'   psi_l = list(t(chol(diag(3))))
#' )
#' data <- as.data.frame(sim)
#'
#' # Fit the model--------------------------------------------------------------
#' library(fitDTVARMx)
#' fit <- FitDTVARIDMx(
#'   data = data,
#'   observed = c("y1", "y2", "y3"),
#'   id = "id"
#' )
#' print(fit)
#' summary(fit)
#' coef(fit)
#' vcov(fit)
#' }
#'
#' @references
#' Hunter, M. D. (2017).
#' State space modeling in an open source, modular,
#' structural equation modeling environment.
#' *Structural Equation Modeling: A Multidisciplinary Journal*,
#' *25*(2), 307–324.
#' \doi{10.1080/10705511.2017.1369354}
#'
#' Neale, M. C., Hunter, M. D., Pritikin, J. N.,
#' Zahery, M., Brick, T. R., Kirkpatrick, R. M., Estabrook, R.,
#' Bates, T. C., Maes, H. H., & Boker, S. M. (2015).
#' OpenMx 2.0: Extended structural equation and statistical modeling.
#' *Psychometrika*,
#' *81*(2), 535–549.
#' \doi{10.1007/s11336-014-9435-8}
#'
#' @family DTVAR Functions
#' @keywords fitDTVARMx fit
#' @import OpenMx
#' @importFrom stats coef vcov
#' @export
FitDTVARIDMx <- function(data,
                         observed,
                         id,
                         alpha_fixed = FALSE,
                         alpha_free = NULL,
                         alpha_values = NULL,
                         alpha_lbound = NULL,
                         alpha_ubound = NULL,
                         beta_fixed = FALSE,
                         beta_free = NULL,
                         beta_values = NULL,
                         beta_lbound = NULL,
                         beta_ubound = NULL,
                         psi_diag = FALSE,
                         psi_d_free = NULL,
                         psi_d_values = NULL,
                         psi_d_lbound = NULL,
                         psi_d_ubound = NULL,
                         psi_l_free = NULL,
                         psi_l_values = NULL,
                         psi_l_lbound = NULL,
                         psi_l_ubound = NULL,
                         theta_fixed = FALSE,
                         theta_d_free = NULL,
                         theta_d_values = NULL,
                         theta_d_lbound = NULL,
                         theta_d_ubound = NULL,
                         mu0_fixed = TRUE,
                         mu0_func = TRUE,
                         mu0_free = NULL,
                         mu0_values = NULL,
                         mu0_lbound = NULL,
                         mu0_ubound = NULL,
                         sigma0_fixed = TRUE,
                         sigma0_func = TRUE,
                         sigma0_diag = FALSE,
                         sigma0_d_free = NULL,
                         sigma0_d_values = NULL,
                         sigma0_d_lbound = NULL,
                         sigma0_d_ubound = NULL,
                         sigma0_l_free = NULL,
                         sigma0_l_values = NULL,
                         sigma0_l_lbound = NULL,
                         sigma0_l_ubound = NULL,
                         try = 1000,
                         ncores = NULL,
                         path = getwd(),
                         prefix = "fitdtvarmxid",
                         clean = TRUE,
                         ...) {
  byid <- TRUE
  args <- list(
    data = data,
    observed = observed,
    id = id,
    alpha_fixed = alpha_fixed,
    alpha_free = alpha_free,
    alpha_values = alpha_values,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    beta_fixed = beta_fixed,
    beta_free = beta_free,
    beta_values = beta_values,
    beta_lbound = beta_lbound,
    beta_ubound = beta_ubound,
    psi_diag = psi_diag,
    psi_d_free = psi_d_free,
    psi_d_values = psi_d_values,
    psi_d_lbound = psi_d_lbound,
    psi_d_ubound = psi_d_ubound,
    psi_l_free = psi_l_free,
    psi_l_values = psi_l_values,
    psi_l_lbound = psi_l_lbound,
    psi_l_ubound = psi_l_ubound,
    theta_fixed = theta_fixed,
    theta_d_free = theta_d_free,
    theta_d_values = theta_d_values,
    theta_d_lbound = theta_d_lbound,
    theta_d_ubound = theta_d_ubound,
    mu0_fixed = mu0_fixed,
    mu0_func = mu0_func,
    mu0_free = mu0_free,
    mu0_values = mu0_values,
    mu0_lbound = mu0_lbound,
    mu0_ubound = mu0_ubound,
    sigma0_fixed = sigma0_fixed,
    sigma0_func = sigma0_func,
    sigma0_diag = sigma0_diag,
    sigma0_d_free = sigma0_d_free,
    sigma0_d_values = sigma0_d_values,
    sigma0_d_lbound = sigma0_d_lbound,
    sigma0_d_ubound = sigma0_d_ubound,
    sigma0_l_free = sigma0_l_free,
    sigma0_l_values = sigma0_l_values,
    sigma0_l_lbound = sigma0_l_lbound,
    sigma0_l_ubound = sigma0_l_ubound,
    try = try,
    ncores = ncores,
    byid = byid,
    path = path,
    prefix = prefix,
    clean = clean,
    ...
  )
  output <- .FitDTVAR(
    data = data,
    observed = observed,
    id = id,
    alpha_fixed = alpha_fixed,
    alpha_free = alpha_free,
    alpha_values = alpha_values,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    beta_fixed = beta_fixed,
    beta_free = beta_free,
    beta_values = beta_values,
    beta_lbound = beta_lbound,
    beta_ubound = beta_ubound,
    psi_diag = psi_diag,
    psi_d_free = psi_d_free,
    psi_d_values = psi_d_values,
    psi_d_lbound = psi_d_lbound,
    psi_d_ubound = psi_d_ubound,
    psi_l_free = psi_l_free,
    psi_l_values = psi_l_values,
    psi_l_lbound = psi_l_lbound,
    psi_l_ubound = psi_l_ubound,
    theta_fixed = theta_fixed,
    theta_d_free = theta_d_free,
    theta_d_values = theta_d_values,
    theta_d_lbound = theta_d_lbound,
    theta_d_ubound = theta_d_ubound,
    mu0_fixed = mu0_fixed,
    mu0_func = mu0_func,
    mu0_free = mu0_free,
    mu0_values = mu0_values,
    mu0_lbound = mu0_lbound,
    mu0_ubound = mu0_ubound,
    sigma0_fixed = sigma0_fixed,
    sigma0_func = sigma0_func,
    sigma0_diag = sigma0_diag,
    sigma0_d_free = sigma0_d_free,
    sigma0_d_values = sigma0_d_values,
    sigma0_d_lbound = sigma0_d_lbound,
    sigma0_d_ubound = sigma0_d_ubound,
    sigma0_l_free = sigma0_l_free,
    sigma0_l_values = sigma0_l_values,
    sigma0_l_lbound = sigma0_l_lbound,
    sigma0_l_ubound = sigma0_l_ubound,
    try = try,
    ncores = ncores,
    byid = byid,
    path = path,
    prefix = prefix,
    clean = clean,
    ...
  )
  out <- list(
    call = match.call(),
    args = args,
    fun = "FitDTVARIDMx",
    output = output
  )
  class(out) <- c(
    "dtvaridmx",
    class(out)
  )
  out
}
