.FitDTVARSigmaFunc <- function(k,
                               statenames) {
  # sigma_values will be implied by the algebra
  # stable covariance
  list(
    sigma_J = OpenMx::mxMatrix(
      type = "Iden",
      nrow = k * k,
      ncol = k * k,
      name = "sigma_J"
    ),
    sigma_vector = OpenMx::mxAlgebraFromString(
      algString = "solve(sigma_J - beta %x% beta) %*% cvectorize(psi)",
      name = "sigma_vector"
    ),
    sigma_mat = OpenMx::mxMatrix(
      "Full",
      nrow = k,
      ncol = k,
      labels = paste0(
        "sigma_vector[",
        1:(k * k),
        ",",
        1,
        "]"
      ),
      dimnames = list(
        statenames,
        statenames
      ),
      name = "sigma_mat"
    ),
    sigma = OpenMx::mxAlgebraFromString(
      algString = "0.5 * (sigma_mat + t(sigma_mat))",
      dimnames = list(
        statenames,
        statenames
      ),
      name = "sigma"
    ),
    sigma_vech = OpenMx::mxAlgebraFromString(
      algString = "vech(sigma_mat)",
      name = "sigma_vech"
    )
  )
}
