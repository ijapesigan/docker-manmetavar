.FitDTVARX <- function(alpha_fixed) {
  # u
  # covariates
  if (alpha_fixed) {
    out <- OpenMx::mxMatrix(
      type = "Zero",
      nrow = 1,
      ncol = 1,
      name = "covariate"
    )
  } else {
    out <- OpenMx::mxMatrix(
      type = "Unit",
      nrow = 1,
      ncol = 1,
      name = "covariate"
    )
  }
  out
}
