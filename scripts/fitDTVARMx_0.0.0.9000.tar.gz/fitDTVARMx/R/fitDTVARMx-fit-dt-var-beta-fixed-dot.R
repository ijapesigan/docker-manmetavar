.FitDTVARBetaFixed <- function(k,
                               beta_values) {
  # A
  # auto regression and cross regression coefficients
  if (is.null(beta_values)) {
    out <- OpenMx::mxMatrix(
      type = "Zero",
      nrow = k,
      ncol = k,
      name = "beta"
    )
  } else {
    out <- OpenMx::mxMatrix(
      type = "Full",
      nrow = k,
      ncol = k,
      free = FALSE,
      values = beta_values,
      byrow = FALSE,
      name = "beta"
    )
  }
  out
}
