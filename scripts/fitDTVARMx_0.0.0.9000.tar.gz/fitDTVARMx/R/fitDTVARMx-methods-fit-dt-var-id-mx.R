#' Print Method for Object of Class `dtvaridmx`
#'
#' @author Ivan Jacob Agaloos Pesigan
#' @param x an object of class `dtvaridmx`.
#' @param means Logical.
#'   If `means = TRUE`, return means.
#'   Otherwise, the function returns raw estimates.
#' @param ... further arguments.
#'
#' @method print dtvaridmx
#' @keywords methods
#' @export
print.dtvaridmx <- function(x,
                            means = FALSE,
                            ...) {
  out <- do.call(
    what = "rbind",
    args = lapply(
      X = x$output,
      FUN = coef
    )
  )
  if (means) {
    cat("\nMeans of the estimated paramaters per individual.\n")
    out <- colMeans(out)
  } else {
    cat("\nEstimated paramaters per individual.\n")
  }
  base::print(out)
}

#' Summary Method for Object of Class `dtvaridmx`
#'
#' @author Ivan Jacob Agaloos Pesigan
#' @param object an object of class `dtvaridmx`.
#' @param means Logical.
#'   If `means = TRUE`, return means.
#'   Otherwise, the function returns raw estimates.
#' @param ... further arguments.
#'
#' @method summary dtvaridmx
#' @keywords methods
#' @export
summary.dtvaridmx <- function(object,
                              means = FALSE,
                              ...) {
  out <- do.call(
    what = "rbind",
    args = lapply(
      X = object$output,
      FUN = coef
    )
  )
  if (means) {
    # nocov start
    if (interactive()) {
      cat("\nMeans of the estimated paramaters per individual.\n")
    }
    # nocov end
    out <- colMeans(out)
  } else {
    # nocov start
    if (interactive()) {
      cat("\nEstimated paramaters per individual.\n")
    }
    # nocov end
  }
  out
}

#' Parameter Estimates
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param object Object of class `dtvaridmx`.
#' @param alpha Logical.
#'   If `alpha = TRUE`,
#'   include estimates of the `alpha` vector, if available.
#'   If `alpha = FALSE`,
#'   exclude estimates of the `alpha` vector.
#' @param psi Logical.
#'   If `psi = TRUE`,
#'   include estimates of the `psi` matrix, if available.
#'   If `psi = FALSE`,
#'   exclude estimates of the `psi` matrix.
#' @param theta Logical.
#'   If `theta = TRUE`,
#'   include estimates of the `theta` matrix, if available.
#'   If `theta = FALSE`,
#'   exclude estimates of the `theta` matrix.
#' @param ... additional arguments.
#' @return Returns a list of vectors of parameter estimates.
#'
#' @method coef dtvaridmx
#' @keywords methods
#' @export
coef.dtvaridmx <- function(object,
                           alpha = TRUE,
                           psi = TRUE,
                           theta = TRUE,
                           ...) {
  thetahat <- OpenMx::mxEvalByName(
    name = "thetahat",
    model = object$output[[1]],
    compute = TRUE
  )
  parnames <- rownames(thetahat)
  idx <- grep(
    pattern = "^beta\\[",
    x = parnames
  )
  if (alpha) {
    idx <- c(
      idx,
      grep(
        pattern = "^alpha\\[",
        x = parnames
      )
    )
  }
  if (psi) {
    idx <- c(
      idx,
      grep(
        pattern = "^psi\\[",
        x = parnames
      )
    )
  }
  if (theta) {
    idx <- c(
      idx,
      grep(
        pattern = "^theta\\[",
        x = parnames
      )
    )
  }
  lapply(
    X = object$output,
    FUN = function(x,
                   idx) {
      thetahat <- OpenMx::mxEvalByName(
        name = "thetahat",
        model = x,
        compute = TRUE
      )
      parnames <- rownames(thetahat)
      coefs <- c(thetahat)
      names(coefs) <- parnames
      coefs[idx]
    },
    idx = idx
  )
}

#' Sampling Covariance Matrix of the Parameter Estimates
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param object Object of class `dtvaridmx`.
#' @param alpha Logical.
#'   If `alpha = TRUE`,
#'   include estimates of the `alpha` vector, if available.
#'   If `alpha = FALSE`,
#'   exclude estimates of the `alpha` vector.
#' @param psi Logical.
#'   If `psi = TRUE`,
#'   include estimates of the `psi` matrix, if available.
#'   If `psi = FALSE`,
#'   exclude estimates of the `psi` matrix.
#' @param theta Logical.
#'   If `theta = TRUE`,
#'   include estimates of the `theta` matrix, if available.
#'   If `theta = FALSE`,
#'   exclude estimates of the `theta` matrix.
#' @param ... additional arguments.
#' @return Returns a list of sampling variance-covariance matrices.
#'
#' @method vcov dtvaridmx
#' @keywords methods
#' @export
vcov.dtvaridmx <- function(object,
                           alpha = TRUE,
                           psi = TRUE,
                           theta = TRUE,
                           ...) {
  thetahat <- OpenMx::mxEvalByName(
    name = "thetahat",
    model = object$output[[1]],
    compute = TRUE
  )
  parnames <- rownames(thetahat)
  idx <- grep(
    pattern = "^beta\\[",
    x = parnames
  )
  if (alpha) {
    idx <- c(
      idx,
      grep(
        pattern = "^alpha\\[",
        x = parnames
      )
    )
  }
  if (psi) {
    idx <- c(
      idx,
      grep(
        pattern = "^psi\\[",
        x = parnames
      )
    )
  }
  if (theta) {
    idx <- c(
      idx,
      grep(
        pattern = "^theta\\[",
        x = parnames
      )
    )
  }
  lapply(
    X = object$output,
    FUN = function(x,
                   idx) {
      thetahat <- OpenMx::mxEvalByName(
        name = "thetahat",
        model = x,
        compute = TRUE
      )
      parnames <- rownames(thetahat)
      vcov <- OpenMx::mxSE(
        x = "thetahat",
        model = x,
        details = TRUE
      )$Cov
      rownames(vcov) <- colnames(vcov) <- parnames
      vcov(x)[idx, idx, drop = FALSE]
    },
    idx = idx
  )
}
