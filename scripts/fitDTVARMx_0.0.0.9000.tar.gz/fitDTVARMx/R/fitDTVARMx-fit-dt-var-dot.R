.FitDTVAR <- function(data,
                      observed,
                      id,
                      alpha_fixed,
                      alpha_free,
                      alpha_values,
                      alpha_lbound,
                      alpha_ubound,
                      beta_fixed,
                      beta_free,
                      beta_values,
                      beta_lbound,
                      beta_ubound,
                      psi_diag,
                      psi_d_free,
                      psi_d_values,
                      psi_d_lbound,
                      psi_d_ubound,
                      psi_l_free,
                      psi_l_values,
                      psi_l_lbound,
                      psi_l_ubound,
                      theta_fixed,
                      theta_d_free,
                      theta_d_values,
                      theta_d_lbound,
                      theta_d_ubound,
                      mu0_fixed,
                      mu0_func,
                      mu0_free,
                      mu0_values,
                      mu0_lbound,
                      mu0_ubound,
                      sigma0_fixed,
                      sigma0_func,
                      sigma0_diag,
                      sigma0_d_free,
                      sigma0_d_values,
                      sigma0_d_lbound,
                      sigma0_d_ubound,
                      sigma0_l_free,
                      sigma0_l_values,
                      sigma0_l_lbound,
                      sigma0_l_ubound,
                      try,
                      ncores,
                      byid,
                      path,
                      prefix,
                      clean,
                      ...) {
  k <- length(observed)
  idx <- seq_len(k)
  statenames <- paste0("eta", idx)
  .FitDTVARRun(
    data = data,
    observed = observed,
    id = id,
    beta = .FitDTVARBeta(
      k = k,
      statenames = statenames,
      beta_fixed = beta_fixed,
      beta_free = beta_free,
      beta_values = beta_values,
      beta_lbound = beta_lbound,
      beta_ubound = beta_ubound
    ),
    gamma = .FitDTVARGamma(
      k = k,
      statenames = statenames,
      alpha_fixed = alpha_fixed,
      alpha_free = alpha_free,
      alpha_values = alpha_values,
      alpha_lbound = alpha_lbound,
      alpha_ubound = alpha_ubound
    ),
    lambda = .FitDTVARLambda(
      k = k,
      observed = observed,
      statenames = statenames
    ),
    kappa = .FitDTVARKappa(
      k = k
    ),
    psi = .FitDTVARPsi(
      k = k,
      statenames = statenames,
      psi_diag = psi_diag,
      psi_d_free = psi_d_free,
      psi_d_values = psi_d_values,
      psi_d_lbound = psi_d_lbound,
      psi_d_ubound = psi_d_ubound,
      psi_l_free = psi_l_free,
      psi_l_values = psi_l_values,
      psi_l_lbound = psi_l_lbound,
      psi_l_ubound = psi_l_ubound
    ),
    theta = .FitDTVARTheta(
      k = k,
      observed = observed,
      theta_fixed = theta_fixed,
      theta_d_free = theta_d_free,
      theta_d_values = theta_d_values,
      theta_d_lbound = theta_d_lbound,
      theta_d_ubound = theta_d_ubound
    ),
    mu0 = .FitDTVARMu0(
      k = k,
      statenames = statenames,
      mu0_fixed = mu0_fixed,
      mu0_func = mu0_func,
      mu0_free = mu0_free,
      mu0_values = mu0_values,
      mu0_lbound = mu0_lbound,
      mu0_ubound = mu0_ubound
    ),
    sigma0 = .FitDTVARSigma0(
      k = k,
      statenames = statenames,
      sigma0_fixed = sigma0_fixed,
      sigma0_func = sigma0_func,
      sigma0_diag = sigma0_diag,
      sigma0_d_free = sigma0_d_free,
      sigma0_d_values = sigma0_d_values,
      sigma0_d_lbound = sigma0_d_lbound,
      sigma0_d_ubound = sigma0_d_ubound,
      sigma0_l_free = sigma0_l_free,
      sigma0_l_values = sigma0_l_values,
      sigma0_l_lbound = sigma0_l_lbound,
      sigma0_l_ubound = sigma0_l_ubound
    ),
    covariate = .FitDTVARX(
      alpha_fixed = alpha_fixed
    ),
    mu = .FitDTVARMuFunc(
      k = k,
      statenames = statenames
    ),
    sigma = .FitDTVARSigmaFunc(
      k = k,
      statenames = statenames
    ),
    try = try,
    ncores = ncores,
    byid = byid,
    path = path,
    prefix = prefix,
    clean = clean,
    ...
  )
}
