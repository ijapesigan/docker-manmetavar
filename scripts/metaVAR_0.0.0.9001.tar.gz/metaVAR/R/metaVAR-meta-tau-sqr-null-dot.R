.MetaTauSqrNull <- function(p) {
  list(
    tau = OpenMx::mxMatrix(
      type = "Zero",
      nrow = p,
      ncol = p,
      name = "tau"
    ),
    tau_sqr = OpenMx::mxMatrix(
      type = "Zero",
      nrow = p,
      ncol = p,
      name = "tau_sqr"
    )
  )
}
