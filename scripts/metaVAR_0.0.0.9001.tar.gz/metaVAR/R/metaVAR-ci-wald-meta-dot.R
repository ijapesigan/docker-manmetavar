.CIWaldMeta <- function(object,
                        alpha) {
  coef_alpha <- OpenMx::mxEvalByName(
    name = "alpha_vec",
    model = object$output,
    compute = TRUE
  )
  names_alpha <- rownames(coef_alpha)
  coef_alpha <- c(coef_alpha)
  names(coef_alpha) <- names_alpha
  se_alpha <- c(
    OpenMx::mxSE(
      x = "alpha_vec",
      model = object$output,
      silent = TRUE
    )
  )
  b0 <- .CIWald(
    est = coef_alpha,
    se = se_alpha,
    theta = 0,
    alpha = alpha,
    z = TRUE,
    test = FALSE
  )
  if (is.null(object$args$x)) {
    b1 <- NULL
  } else {
    coef_gamma <- OpenMx::mxEvalByName(
      name = "gamma_vec",
      model = object$output,
      compute = TRUE
    )
    names_gamma <- rownames(coef_gamma)
    coef_gamma <- c(coef_gamma)
    names(coef_gamma) <- names_gamma
    se_gamma <- c(
      OpenMx::mxSE(
        x = "gamma_vec",
        model = object$output,
        silent = TRUE
      )
    )
    b1 <- .CIWald(
      est = coef_gamma,
      se = se_gamma,
      theta = 0,
      alpha = alpha,
      z = TRUE,
      test = FALSE
    )
  }
  if (object$args$random) {
    coef_tau_sqr <- OpenMx::mxEvalByName(
      name = "tau_sqr_vec",
      model = object$output,
      compute = TRUE
    )
    names_tau_sqr <- rownames(coef_tau_sqr)
    coef_tau_sqr <- c(coef_tau_sqr)
    names(coef_tau_sqr) <- names_tau_sqr
    se_tau_sqr <- c(
      OpenMx::mxSE(
        x = "tau_sqr_vec",
        model = object$output,
        silent = TRUE
      )
    )
    t2 <- .CIWald(
      est = coef_tau_sqr,
      se = se_tau_sqr,
      theta = 0,
      alpha = alpha,
      z = TRUE,
      test = FALSE
    )
    coef_i_sqr <- OpenMx::mxEvalByName(
      name = "i_sqr_vec",
      model = object$output,
      compute = TRUE
    )
    names_i_sqr <- gsub(
      pattern = "^alpha",
      replacement = "i_sqr",
      x = names_alpha
    )
    coef_i_sqr <- c(coef_i_sqr)
    names(coef_i_sqr) <- names_i_sqr
    se_i_sqr <- c(
      OpenMx::mxSE(
        x = "i_sqr_vec",
        model = object$output,
        silent = TRUE
      )
    )
    i2 <- .CIWald(
      est = coef_i_sqr,
      se = se_i_sqr,
      theta = 0,
      alpha = alpha,
      z = TRUE,
      test = FALSE
    )
  } else {
    t2 <- NULL
    i2 <- NULL
  }
  ci <- list(
    b0 = b0,
    b1 = b1,
    t2 = t2,
    i2 = i2
  )
  ci <- ci[
    !sapply(
      X = ci,
      FUN = is.null
    )
  ]
  do.call(
    what = "rbind",
    args = ci
  )
}
