.MetaTauSqr <- function(v,
                        p,
                        n,
                        vnames,
                        tau_sqr_d_free,
                        tau_sqr_d_values,
                        tau_sqr_d_lbound,
                        tau_sqr_d_ubound,
                        tau_sqr_l_free,
                        tau_sqr_l_values,
                        tau_sqr_l_lbound,
                        tau_sqr_l_ubound,
                        random,
                        diag) {
  idx <- seq_len(p)
  if (random) {
    if (diag) {
      tau <- .MetaTauSqrDiag(
        p = p,
        idx = idx,
        tau_sqr_d_free = tau_sqr_d_free,
        tau_sqr_d_values = tau_sqr_d_values,
        tau_sqr_d_lbound = tau_sqr_d_lbound,
        tau_sqr_d_ubound = tau_sqr_d_ubound,
        tau_sqr_d_equal = FALSE
      )
    } else {
      tau <- .MetaTauSqrSym(
        p = p,
        idx = idx,
        tau_sqr_d_free = tau_sqr_d_free,
        tau_sqr_d_values = tau_sqr_d_values,
        tau_sqr_d_lbound = tau_sqr_d_lbound,
        tau_sqr_d_ubound = tau_sqr_d_ubound,
        tau_sqr_l_free = tau_sqr_l_free,
        tau_sqr_l_values = tau_sqr_l_values,
        tau_sqr_l_lbound = tau_sqr_l_lbound,
        tau_sqr_l_ubound = tau_sqr_l_ubound,
        tau_sqr_d_equal = FALSE
      )
    }
  } else {
    tau <- .MetaTauSqrNull(
      p = p
    )
  }
  c(
    v = .V(
      vnames = vnames,
      p = p
    ),
    v_hat = .VHat(
      v = v,
      p = p,
      n = n,
      univariate = FALSE
    ),
    tau = tau,
    i_sqr = .MetaISqr(univariate = FALSE),
    expected_covariance = .MetaExpectedCovariances()
  )
}
