#' Print Method for Object of Class `metavarmeta`
#'
#' @author Ivan Jacob Agaloos Pesigan
#' @param x an object of class `metavarmeta`.
#' @param alpha Numeric vector.
#'   Significance level \eqn{\alpha}.
#' @param digits Integer indicating the number of decimal places to display.
#' @param ... further arguments.
#'
#' @return Returns a matrix of
#'   estimates,
#'   standard errors,
#'   test statistics,
#'   degrees of freedom,
#'   p-values,
#'   and
#'   confidence intervals.
#'
#' @method print metavarmeta
#' @keywords methods
#' @export
print.metavarmeta <- function(x,
                              alpha = 0.05,
                              digits = 4,
                              ...) {
  print.summary.metavarmeta(
    summary.metavarmeta(
      object = x,
      alpha = alpha,
      digits = digits
    )
  )
}

#' Summary Method for Object of Class `metavarmeta`
#'
#' @author Ivan Jacob Agaloos Pesigan
#' @param object an object of class `metavarmeta`.
#' @param alpha Numeric vector.
#'   Significance level \eqn{\alpha}.
#' @param digits Integer indicating the number of decimal places to display.
#' @param ... further arguments.
#'
#' @return Returns a matrix of
#'   estimates,
#'   standard errors,
#'   test statistics,
#'   degrees of freedom,
#'   p-values,
#'   and
#'   confidence intervals.
#'
#' @method summary metavarmeta
#' @keywords methods
#' @export
summary.metavarmeta <- function(object,
                                alpha = 0.05,
                                digits = 4,
                                ...) {
  ci <- .CIWaldMeta(
    object = object,
    alpha = alpha
  )
  print_summary <- round(
    x = ci,
    digits = digits
  )
  class(ci) <- c(
    "summary.metavarmeta",
    class(ci)
  )
  attr(ci, "fit") <- object
  attr(ci, "alpha") <- alpha
  attr(ci, "digits") <- digits
  attr(ci, "print_summary") <- print_summary
  ci
}

#' @noRd
#' @keywords internal
#' @exportS3Method print summary.metavarmeta
print.summary.metavarmeta <- function(x,
                                      ...) {
  print_summary <- attr(
    x = x,
    which = "print_summary"
  )
  object <- attr(
    x = x,
    which = "fit"
  )
  cat("Call:\n")
  base::print(object$call)
  print(print_summary)
  invisible(x)
}

#' Estimated Parameter Method for an Object of Class
#' `metavarmeta`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a vector of estimated parameters.
#'
#' @inheritParams summary.metavarmeta
#'
#' @method coef metavarmeta
#' @keywords methods
#' @export
coef.metavarmeta <- function(object,
                             ...) {
  coef(object$output)
}

#' Variance-Covariance Matrix Method for an Object of Class
#' `metavarmeta`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns the sampling variance-covariance matrix
#'   of the estimated parameters.
#'
#' @inheritParams summary.metavarmeta
#'
#' @method vcov metavarmeta
#' @keywords methods
#' @export
vcov.metavarmeta <- function(object,
                             ...) {
  vcov(object$output)
}

#' Confidence Intervals for the Parameter Estimates
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param object Object of class `metavarmeta`.
#' @param ... additional arguments.
#' @param parm a specification of which parameters
#'   are to be given confidence intervals,
#'   either a vector of numbers or a vector of names.
#'   If missing, all parameters are considered.
#' @param level the confidence level required.
#' @param lb Logical.
#'   If `TRUE`, returns profile likelihood-based confidence intervals.
#'   If `FALSE`, returns Wald confidence intervals.
#' @return Returns a matrix of confidence intervals.
#'
#' @method confint metavarmeta
#' @keywords methods
#' @export
confint.metavarmeta <- function(object,
                                parm = NULL,
                                level = 0.95,
                                lb = TRUE,
                                ...) {
  stopifnot(
    length(level) == 1
  )
  wald <- .CIWaldMeta(
    object = object,
    alpha = 1 - level
  )[, 5:6, drop = FALSE]
  if (lb) {
    ci <- .CILBMeta(
      object = object,
      alpha = 1 - level
    )[, 2:3, drop = FALSE]
    ci <- ci[
      rownames(wald), ,
      drop = FALSE
    ]
  } else {
    ci <- wald
  }
  if (is.null(parm)) {
    parameters <- rownames(
      ci
    )
    if (!is.null(parameters)) {
      parm <- parameters
    } else {
      parm <- seq_len(dim(ci)[1])
    }
  }
  ci <- ci[parm, , drop = FALSE]
  varnames <- colnames(ci)
  varnames <- gsub(
    pattern = "%",
    replacement = " %",
    x = varnames
  )
  colnames(ci) <- varnames
  ci
}

#' Extract Generic Function
#'
#' A generic function for extracting elements from objects.
#'
#' @param object An object.
#' @param what Character string.
#' @return A value determined by the specific method for the object's class.
#' @keywords methods
#' @export
extract <- function(object,
                    what) {
  UseMethod("extract")
}

#' Extract Method for an Object of Class
#' `metavarmeta`
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @return Returns a list estimates.
#'
#' @param object Object of Class `metavarmeta`.
#' @param what Character string.
#'   What specific matrix to extract.
#'   If `what = NULL`,
#'   extract all available matrices.
#'
#' @keywords methods
#' @export
#' @method extract metavarmeta
extract.metavarmeta <- function(object,
                                what = NULL) {
  out <- .MetaExtract(object = object)
  if (!is.null(what)) {
    stopifnot(
      what %in% c(
        "alpha",
        "beta",
        "gamma",
        "tau_sqr",
        "i_sqr"
      )
    )
    out <- out[[what]]
  }
  out
}
