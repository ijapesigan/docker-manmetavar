.MetaMixed <- function(p,
                       m,
                       ynames,
                       xnames,
                       alpha_values,
                       alpha_free,
                       alpha_lbound,
                       alpha_ubound,
                       gamma_values,
                       gamma_free,
                       gamma_lbound,
                       gamma_ubound) {
  alpha <- .MetaAlpha(
    p = p,
    ynames = ynames,
    alpha_free = alpha_free,
    alpha_values = alpha_values,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound
  )
  if (is.null(m) || m == 0) {
    mixed <- FALSE
    out <- list(
      alpha
    )
  } else {
    mixed <- TRUE
    gamma <- .MetaGamma(
      p = p,
      m = m,
      ynames = ynames,
      xnames = xnames,
      gamma_values = gamma_values,
      gamma_free = gamma_free,
      gamma_lbound = gamma_lbound,
      gamma_ubound = gamma_ubound
    )
    x_labels <- matrix(
      data = paste0(
        "data.",
        xnames
      ),
      nrow = m,
      ncol = 1
    )
    x <- OpenMx::mxMatrix(
      type = "Full",
      nrow = m,
      ncol = 1,
      free = FALSE,
      labels = x_labels,
      name = "x"
    )
    out <- list(
      x,
      alpha,
      gamma
    )
  }
  expected_mean <- .MetaExpectedMeans(
    mixed = mixed
  )
  c(
    out,
    expected_mean
  )
}
