.MxHelperMuSigma <- function(x,
                             ...) {
  x <- as.data.frame(x)
  manifests <- names(x)
  p <- length(manifests)
  start_s <- stats::cov(
    x = x,
    use = "pairwise.complete.obs"
  )
  if (anyNA(start_s)) {
    start_s <- diag(p)
  }
  start_s <- tryCatch(
    as.matrix(
      Matrix::nearPD(
        x = start_s,
        corr = FALSE
      )$mat
    ),
    error = function(e) as.matrix(start_s)
  )
  l_start <- tryCatch(
    t(chol(start_s)),
    error = function(e) {
      ev <- eigen(
        x = start_s,
        symmetric = TRUE
      )
      ev$values[ev$values < 1e-8] <- 1e-8
      s_fix <- ev$vectors %*% diag(ev$values, p) %*% t(ev$vectors)
      t(chol(s_fix))
    }
  )
  start_m <- colMeans(
    x = x,
    na.rm = TRUE
  )
  lbound_l <- matrix(
    data = NA_real_,
    nrow = p,
    ncol = p
  )
  diag(lbound_l) <- 1e-6
  OpenMx::mxTryHard(
    model = OpenMx::mxModel(
      model = "FIML",
      OpenMx::mxData(
        observed = x,
        type = "raw"
      ),
      OpenMx::mxMatrix(
        type = "Lower",
        nrow = p,
        ncol = p,
        free = TRUE,
        values = l_start,
        lbound = lbound_l,
        name = "l",
        dimnames = list(
          manifests,
          manifests
        )
      ),
      OpenMx::mxAlgebraFromString(
        algString = "l %*% t(l)",
        name = "sigma"
      ),
      OpenMx::mxMatrix(
        type = "Full",
        nrow = 1,
        ncol = p,
        free = TRUE,
        values = start_m,
        name = "mu",
        dimnames = list(
          NULL,
          manifests
        )
      ),
      OpenMx::mxExpectationNormal(
        covariance = "sigma",
        means = "mu",
        dimnames = manifests
      ),
      OpenMx::mxFitFunctionML()
    ),
    ...
  )
}
