## ---- test-metaVAR-mixed-effects
lapply(
  X = 1,
  FUN = function(i,
                 text,
                 n,
                 mu,
                 gamma,
                 tol) {
    message(text)
    set.seed(42)
    testthat::test_that(
      text,
      {
        x <- lapply(
          X = seq_len(n),
          FUN = function(i) {
            MASS::mvrnorm(
              n = 1,
              mu = c(0, 0, 0),
              Sigma = diag(3)
            )
          }
        )
        gamma_covariate <- lapply(
          X = x,
          FUN = function(i) {
            c(
              gamma %*% i
            )
          }
        )
        random_effects <- function() {
          fit <- metaVAR:::.MxHelperMuSigma(
            MASS::mvrnorm(
              n = n,
              mu = MASS::mvrnorm(
                n = 1,
                mu = mu,
                Sigma = matrix(
                  data = c(1, .80, .80, 1),
                  nrow = 2,
                  ncol = 2
                )
              ),
              Sigma = diag(2)
            )
          )
          coefs <- c(
            OpenMx::mxEvalByName(
              name = "mu",
              model = fit
            )
          )
          vcovs <- OpenMx::mxSE(
            x = "mu",
            model = fit,
            details = TRUE
          )$Cov
          list(
            coef = coefs,
            vcov = vcovs
          )
        }
        estimates <- lapply(
          X = seq_len(n),
          FUN = function(i) {
            random_effects()
          }
        )
        y_orig <- lapply(
          X = estimates,
          FUN = function(i) {
            i$coef
          }
        )
        y <- lapply(
          X = seq_len(n),
          FUN = function(i) {
            y_orig[[i]] + gamma_covariate[[i]]
          }
        )
        v <- lapply(
          X = estimates,
          FUN = function(i) {
            i$vcov
          }
        )
        mixed <- Meta(
          y = y,
          v = v,
          x = x,
          random = TRUE
        )
        coefs <- coef(mixed)
        testthat::skip_on_cran()
        testthat::expect_true(
          all(
            abs(
              coefs[1:2] - mu
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            abs(
              coefs[3:8] - c(gamma)
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            c(
              summary(mixed)[9:length(coefs), "p"]
            ) < 0.05
          )
        )
      }
    )
  },
  text = "test-metaVAR-mixed-effects",
  n = 1000,
  mu = c(0, 0),
  gamma = matrix(
    data = 1,
    nrow = 2,
    ncol = 3
  ),
  tol = 0.10
)
