## ---- test-metaVAR-random-effects
lapply(
  X = 1,
  FUN = function(i,
                 text,
                 n,
                 mu,
                 tol) {
    message(text)
    set.seed(42)
    testthat::test_that(
      text,
      {
        random_effects <- function() {
          fit <- metaVAR:::.MxHelperMuSigma(
            MASS::mvrnorm(
              n = n,
              mu = MASS::mvrnorm(
                n = 1,
                mu = mu,
                Sigma = matrix(
                  data = c(1, .80, .80, 1),
                  nrow = 2,
                  ncol = 2
                )
              ),
              Sigma = diag(2)
            )
          )
          coefs <- c(
            OpenMx::mxEvalByName(
              name = "mu",
              model = fit
            )
          )
          vcovs <- OpenMx::mxSE(
            x = "mu",
            model = fit,
            details = TRUE
          )$Cov
          list(
            coef = coefs,
            vcov = vcovs
          )
        }
        estimates <- lapply(
          X = seq_len(n),
          FUN = function(i) {
            random_effects()
          }
        )
        y <- lapply(
          X = estimates,
          FUN = function(i) {
            i$coef
          }
        )
        v <- lapply(
          X = estimates,
          FUN = function(i) {
            i$vcov
          }
        )
        random <- Meta(
          y = y,
          v = v,
          random = TRUE
        )
        coefs <- coef(random)
        testthat::skip_on_cran()
        testthat::expect_true(
          all(
            abs(
              coefs[1:2] - mu
            ) <= tol
          )
        )
        testthat::expect_true(
          all(
            c(
              summary(random)[3:length(coefs), "p"]
            ) < 0.05
          )
        )
      }
    )
  },
  text = "test-metaVAR-random-effects",
  n = 1000,
  mu = c(0, 0),
  tol = 0.10
)
