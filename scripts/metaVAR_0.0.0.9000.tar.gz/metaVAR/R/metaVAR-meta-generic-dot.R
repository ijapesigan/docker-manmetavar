.MetaGeneric <- function(y,
                         v,
                         x,
                         p,
                         m,
                         n,
                         alpha_free,
                         alpha_values,
                         alpha_lbound,
                         alpha_ubound,
                         gamma_free,
                         gamma_values,
                         gamma_lbound,
                         gamma_ubound,
                         tau_sqr_d_free,
                         tau_sqr_d_values,
                         tau_sqr_d_lbound,
                         tau_sqr_d_ubound,
                         tau_sqr_l_free,
                         tau_sqr_l_values,
                         tau_sqr_l_lbound,
                         tau_sqr_l_ubound,
                         random,
                         diag,
                         try,
                         ncores,
                         ...) {
  threads <- OpenMx::mxOption(
    key = "Number of Threads"
  )
  on.exit(
    OpenMx::mxOption(
      key = "Number of Threads",
      value = threads
    )
  )
  idx <- seq_len(p)
  ynames <- paste0(
    "y",
    idx
  )
  vnames <- .Vech(
    x = outer(
      X = idx,
      Y = idx,
      FUN = function(x, y) {
        paste0(
          "v",
          x,
          y
        )
      }
    )
  )
  if (!is.null(x)) {
    xnames <- paste0(
      "x",
      seq_len(m)
    )
  } else {
    xnames <- NULL
  }
  estimates <- .CheckEstimates(
    y = y,
    v = v,
    p = p,
    ynames = ynames,
    ncores = ncores
  )
  y <- estimates$y
  v <- estimates$v
  # nocov start
  if (!is.null(ncores)) {
    ncores <- as.integer(ncores)
    if (ncores > 1) {
      OpenMx::mxOption(
        key = "Number of Threads",
        value = ncores
      )
    }
  }
  # nocov end
  mixed <- .MetaMixed(
    p = p,
    m = m,
    ynames = ynames,
    xnames = xnames,
    alpha_values = alpha_values,
    alpha_free = alpha_free,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    gamma_values = gamma_values,
    gamma_free = gamma_free,
    gamma_lbound = gamma_lbound,
    gamma_ubound = gamma_ubound
  )
  tau_sqr <- .MetaTauSqr(
    v = v,
    p = p,
    n = n,
    vnames = vnames,
    tau_sqr_d_free = tau_sqr_d_free,
    tau_sqr_d_values = tau_sqr_d_values,
    tau_sqr_d_lbound = tau_sqr_d_lbound,
    tau_sqr_d_ubound = tau_sqr_d_ubound,
    tau_sqr_l_free = tau_sqr_l_free,
    tau_sqr_l_values = tau_sqr_l_values,
    tau_sqr_l_lbound = tau_sqr_l_lbound,
    tau_sqr_l_ubound = tau_sqr_l_ubound,
    random = random,
    diag = diag
  )
  model <- OpenMx::mxModel(
    model = "Model",
    mixed,
    tau_sqr,
    OpenMx::mxData(
      type = "raw",
      observed = .PrepData(
        y = y,
        v = v,
        x = x,
        ynames = ynames,
        vnames = vnames,
        xnames = xnames
      )
    ),
    OpenMx::mxExpectationNormal(
      covariance = "expected_covariance",
      means = "expected_mean",
      dimnames = ynames
    ),
    OpenMx::mxFitFunctionML()
  )
  OpenMx::mxTryHard(
    model = model,
    extraTries = try,
    intervals = TRUE,
    ...
  )
}
