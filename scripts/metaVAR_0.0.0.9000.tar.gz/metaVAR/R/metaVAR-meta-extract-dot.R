.MetaExtract <- function(object) {
  p <- object$args$p
  m <- object$args$m
  coefs <- summary(object)
  parnames <- rownames(
    coefs
  )
  coefs <- coefs[, 1]
  names(coefs) <- parnames
  out <- list()
  alpha_names <- parnames[
    grep(
      pattern = "^alpha",
      x = parnames
    )
  ]
  if (length(alpha_names) > 0) {
    out <- c(
      out,
      alpha = list(unname(coefs[alpha_names]))
    )
  }
  beta_names <- parnames[
    grep(
      pattern = "^beta",
      x = parnames
    )
  ]
  if (length(beta_names) > 0) {
    beta <- matrix(
      data = 0,
      nrow = p,
      ncol = m
    )
    for (j in seq_len(m)) {
      for (i in seq_len(p)) {
        beta_ij <- paste0("beta[", i, ",", j, "]")
        if (
          paste0("beta[", i, ",", j, "]") %in% beta_names
        ) {
          beta[i, j] <- coefs[beta_ij]
        }
      }
    }
    out <- c(
      out,
      beta = list(beta)
    )
  }
  gamma_names <- parnames[
    grep(
      pattern = "^gamma",
      x = parnames
    )
  ]
  if (length(gamma_names) > 0) {
    gamma <- matrix(
      data = 0,
      nrow = p,
      ncol = m
    )
    for (j in seq_len(m)) {
      for (i in seq_len(p)) {
        gamma_ij <- paste0("gamma[", i, ",", j, "]")
        if (
          paste0("gamma[", i, ",", j, "]") %in% gamma_names
        ) {
          gamma[i, j] <- coefs[gamma_ij]
        }
      }
    }
    out <- c(
      out,
      gamma = list(gamma)
    )
  }
  tau_sqr_names <- parnames[
    grep(
      pattern = "^tau_sqr",
      x = parnames
    )
  ]
  if (length(tau_sqr_names) > 0) {
    tau_sqr <- matrix(
      data = 0,
      nrow = p,
      ncol = p
    )
    for (j in seq_len(p)) {
      for (i in seq_len(p)) {
        tau_sqr_ij <- paste0("tau_sqr[", i, ",", j, "]")
        if (
          paste0("tau_sqr[", i, ",", j, "]") %in% tau_sqr_names
        ) {
          tau_sqr[i, j] <- coefs[tau_sqr_ij]
          tau_sqr[j, i] <- tau_sqr[i, j]
        }
      }
    }
    out <- c(
      out,
      tau_sqr = list(tau_sqr)
    )
  }
  i_sqr_names <- parnames[
    grep(
      pattern = "^i_sqr",
      x = parnames
    )
  ]
  if (length(i_sqr_names) > 0) {
    out <- c(
      out,
      i_sqr = list(unname(coefs[i_sqr_names]))
    )
  }
  out
}
