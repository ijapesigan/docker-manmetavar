.MxHelperRun <- function(model,
                         grad_tol = 1e-3,
                         hess_tol = 1e-6,
                         silent = FALSE,
                         ...) {
  # Check if the model needs to be run
  run <- is.null(model$output) ||
    is.null(model$output$status) ||
    model$output$status$code != 0L

  # If it looks fitted, check quality of the fit
  if (!run) {
    good_fit <- .MxHelperIsGoodFit(
      x   = model,
      tol = grad_tol
    )
    pd_hessian <- .MxHelperHasPdHessian(
      x   = model,
      tol = hess_tol
    )
    run <- !(good_fit && pd_hessian)
  }
  if (run) {
    model <- OpenMx::mxTryHard(
      model = model,
      silent = silent,
      ...
    )
  }
  model
}
