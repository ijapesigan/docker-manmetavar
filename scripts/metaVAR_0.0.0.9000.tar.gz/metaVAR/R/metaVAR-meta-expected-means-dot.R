.MetaExpectedMeans <- function(mixed) {
  if (mixed) {
    out <- list(
      OpenMx::mxAlgebraFromString(
        algString = "t(alpha + gamma %*% x)",
        name = "expected_mean"
      )
    )
  } else {
    out <- list(
      OpenMx::mxAlgebraFromString(
        algString = "t(alpha)",
        name = "expected_mean"
      )
    )
  }
  out
}
