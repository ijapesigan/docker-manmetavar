#' Fit Multivariate Meta-Analysis
#'
#' This function estimates
#' fixed-, random-, or mixed-effects meta-analysis parameters
#' using the estimated coefficients and sampling variance-covariance matrix
#' from each individual.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param y A list.
#'   Each element of the list is a numeric vector
#'   of estimated coefficients.
#' @param v A list.
#'   Each element of the list
#'   is a sampling variance-covariance matrix of `y`.
#' @param x An optional list.
#'   Each element of the list is a numeric vector
#'   of covariates for the mixed-effects model.
#' @param alpha_values Numeric vector.
#'   Optional vector of starting values for `alpha`.
#' @param alpha_free Logical vector.
#'   Optional vector of free (`TRUE`) parameters for `alpha`.
#' @param alpha_lbound Numeric vector.
#'   Optional vector of lower bound values for `alpha`.
#' @param alpha_ubound Numeric vector.
#'   Optional vector of upper bound values for `alpha`.
#' @param gamma_values Numeric matrix.
#'   Optional matrix of starting values for `gamma`.
#' @param gamma_free Logical matrix.
#'   Optional matrix of free (`TRUE`) parameters for `gamma`.
#' @param gamma_lbound Numeric matrix.
#'   Optional matrix of lower bound values for `gamma`.
#' @param gamma_ubound Numeric matrix.
#'   Optional matrix of upper bound values for `gamma`.
#' @param tau_sqr_d_free Logical vector
#'   indicating free/fixed status of the elements of `tau_sqr_d`.
#'   If `NULL`, all element of `tau_sqr_d` are free.
#' @param tau_sqr_d_values Numeric vector
#'   with starting values for `tau_sqr_d`.
#'   If `NULL`, defaults to a vector of ones.
#' @param tau_sqr_d_lbound Numeric vector
#'   with lower bounds for `tau_sqr_d`.
#'   If `NULL`, no lower bounds are set.
#' @param tau_sqr_d_ubound Numeric vector
#'   with upper bounds for `tau_sqr_d`.
#'   If `NULL`, no upper bounds are set.
#' @param tau_sqr_l_free Logical matrix
#'   indicating which strictly-lower-triangular elements
#'   of `tau_sqr_l` are free.
#'   Ignored if `diag = TRUE`.
#' @param tau_sqr_l_values Numeric matrix
#'   of starting values for the strictly-lower-triangular elements
#'   of `tau_sqr_l`.
#'   If `NULL`, defaults to a null matrix.
#' @param tau_sqr_l_lbound Numeric matrix
#'   with lower bounds for `tau_sqr_l`.
#'   If `NULL`, no lower bounds are set.
#' @param tau_sqr_l_ubound Numeric matrix
#'   with upper bounds for `tau_sqr_l`.
#'   If `NULL`, no upper bounds are set.
#' @param random Logical.
#'   If `random = TRUE`,
#'   estimates random effects.
#'   If `random = FALSE`,
#'   `tau_sqr` is a null matrix.
#' @param diag Logical.
#'   If `diag = TRUE`,
#'   `tau_sqr` is a diagonal matrix.
#'   If `diag = FALSE`,
#'   `tau_sqr` is a symmetric matrix.
#' @param try Positive integer.
#'   Number of extra optimization tries.
#' @param ncores Positive integer.
#'   Number of cores to use.
#' @param ... Additional arguments to pass to [OpenMx::mxTryHard()].
#'
#' @references
#' Cheung, M. W.-L. (2015).
#' *Meta-analysis: A structural equation modeling approach*.
#' Wiley.
#' \doi{10.1002/9781118957813}
#'
#' Neale, M. C., Hunter, M. D., Pritikin, J. N.,
#' Zahery, M., Brick, T. R., Kirkpatrick, R. M., Estabrook, R.,
#' Bates, T. C., Maes, H. H., & Boker, S. M. (2015).
#' OpenMx 2.0: Extended structural equation and statistical modeling.
#' *Psychometrika*,
#' *81*(2), 535–549.
#' \doi{10.1007/s11336-014-9435-8}
#'
#' @family Meta-Analysis of VAR Functions
#' @keywords metaVAR meta
#' @import OpenMx
#' @importFrom stats coef vcov
#' @export
Meta <- function(y,
                 v,
                 x = NULL,
                 alpha_values = NULL,
                 alpha_free = NULL,
                 alpha_lbound = NULL,
                 alpha_ubound = NULL,
                 gamma_values = NULL,
                 gamma_free = NULL,
                 gamma_lbound = NULL,
                 gamma_ubound = NULL,
                 tau_sqr_d_free = NULL,
                 tau_sqr_d_values = NULL,
                 tau_sqr_d_lbound = NULL,
                 tau_sqr_d_ubound = NULL,
                 tau_sqr_l_free = NULL,
                 tau_sqr_l_values = NULL,
                 tau_sqr_l_lbound = NULL,
                 tau_sqr_l_ubound = NULL,
                 random = TRUE,
                 diag = FALSE,
                 try = 1000,
                 ncores = NULL,
                 ...) {
  p <- length(y[[1]])
  n <- length(y)
  stopifnot(
    length(v) == length(y)
  )
  if (is.null(x)) {
    m <- NULL
  } else {
    m <- length(x[[1]])
    stopifnot(
      length(x) == length(y)
    )
  }
  args <- list(
    y = y,
    v = v,
    x = x,
    p = p,
    m = m,
    n = n,
    alpha_values = alpha_values,
    alpha_free = alpha_free,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    gamma_values = gamma_values,
    gamma_free = gamma_free,
    gamma_lbound = gamma_lbound,
    gamma_ubound = gamma_ubound,
    tau_sqr_d_free = tau_sqr_d_free,
    tau_sqr_d_values = tau_sqr_d_values,
    tau_sqr_d_lbound = tau_sqr_d_lbound,
    tau_sqr_d_ubound = tau_sqr_d_ubound,
    tau_sqr_l_free = tau_sqr_l_free,
    tau_sqr_l_values = tau_sqr_l_values,
    tau_sqr_l_lbound = tau_sqr_l_lbound,
    tau_sqr_l_ubound = tau_sqr_l_ubound,
    random = random,
    diag = diag,
    try = try,
    ncores = ncores,
    ...
  )
  output <- .MetaGeneric(
    y = y,
    v = v,
    x = x,
    p = p,
    m = m,
    n = n,
    alpha_free = alpha_free,
    alpha_values = alpha_values,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    gamma_free = gamma_free,
    gamma_values = gamma_values,
    gamma_lbound = gamma_lbound,
    gamma_ubound = gamma_ubound,
    tau_sqr_d_free = tau_sqr_d_free,
    tau_sqr_d_values = tau_sqr_d_values,
    tau_sqr_d_lbound = tau_sqr_d_lbound,
    tau_sqr_d_ubound = tau_sqr_d_ubound,
    tau_sqr_l_free = tau_sqr_l_free,
    tau_sqr_l_values = tau_sqr_l_values,
    tau_sqr_l_lbound = tau_sqr_l_lbound,
    tau_sqr_l_ubound = tau_sqr_l_ubound,
    random = random,
    diag = diag,
    try = try,
    ncores = ncores,
    ...
  )
  out <- list(
    call = match.call(),
    args = args,
    fun = "Meta",
    output = output
  )
  class(out) <- c(
    "metavarmeta",
    class(out)
  )
  out
}
