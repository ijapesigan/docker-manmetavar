.MetaExpectedCovariances <- function() {
  list(
    OpenMx::mxAlgebraFromString(
      algString = "v + tau_sqr",
      name = "expected_covariance"
    )
  )
}
