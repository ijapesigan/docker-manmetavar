#' Fit Multivariate Meta-Analysis
#'
#' This function estimates
#' fixed-, random-, or mixed-effects meta-analysis parameters
#' using the estimated coefficients and sampling variance-covariance matrix
#' from each individual fitted using the
#' [fitDTVARMxID::FitDTVARMxID()] function.
#'
#' @author Ivan Jacob Agaloos Pesigan
#'
#' @param object Output of the [fitDTVARMxID::FitDTVARMxID()] function.
#' @param effects Logical.
#'   If `effects = TRUE`,
#'   include estimates of the dynamic effects matrix, if available.
#'   If `effects = FALSE`,
#'   exclude estimates of the dynamic effects matrix.
#' @param int_meas Logical.
#'   If `int_meas = TRUE`,
#'   include estimates of the measurement intercept vector, if available.
#'   If `int_meas = FALSE`,
#'   exclude estimates of the measurement intercept vector.
#' @param int_dyn Logical.
#'   If `int_dyn = TRUE`,
#'   include estimates of the dynamic process intercept vector, if available.
#'   If `int_dyn = FALSE`,
#'   exclude estimates of the dynamic process intercept vector.
#' @param cov_meas Logical.
#'   If `cov_meas = TRUE`,
#'   include estimates of the measurement error covariance matrix, if available.
#'   If `cov_meas = FALSE`,
#'   exclude estimates of the measurement error covariance matrix.
#' @param cov_dyn Logical.
#'   If `cov_dyn = TRUE`,
#'   include estimates of the process noise covariance matrix, if available.
#'   If `cov_dyn = FALSE`,
#'   exclude estimates of the process noise covariance matrix.
#' @param converged Logical.
#'   Only include converged cases.
#' @param grad_tol Numeric scalar.
#'   Tolerance for the maximum absolute gradient
#'   if `converged = TRUE`.
#' @param hess_tol Numeric scalar.
#'   Tolerance for Hessian eigenvalues;
#'   eigenvalues must be strictly greater than this value
#'   if `converged = TRUE`.
#' @param vanishing_theta Logical.
#'   Test for measurement error variance going to zero
#'   if `converged = TRUE`.
#' @param theta_tol Numeric.
#'   Tolerance for vanishing theta test
#'   if `converged` and `theta_tol` are `TRUE`.
#' @inheritParams Meta
#'
#' @references
#' Cheung, M. W.-L. (2015).
#' *Meta-analysis: A structural equation modeling approach*.
#' Wiley.
#' \doi{10.1002/9781118957813}
#'
#' Neale, M. C., Hunter, M. D., Pritikin, J. N.,
#' Zahery, M., Brick, T. R., Kirkpatrick, R. M., Estabrook, R.,
#' Bates, T. C., Maes, H. H., & Boker, S. M. (2015).
#' OpenMx 2.0: Extended structural equation and statistical modeling.
#' *Psychometrika*,
#' *81*(2), 535–549.
#' \doi{10.1007/s11336-014-9435-8}
#'
#' @family Meta-Analysis of VAR Functions
#' @keywords metaVAR meta
#' @export
MetaVARMx <- function(object,
                      x = NULL,
                      alpha_values = NULL,
                      alpha_free = NULL,
                      alpha_lbound = NULL,
                      alpha_ubound = NULL,
                      gamma_values = NULL,
                      gamma_free = NULL,
                      gamma_lbound = NULL,
                      gamma_ubound = NULL,
                      tau_sqr_d_free = NULL,
                      tau_sqr_d_values = NULL,
                      tau_sqr_d_lbound = NULL,
                      tau_sqr_d_ubound = NULL,
                      tau_sqr_l_free = NULL,
                      tau_sqr_l_values = NULL,
                      tau_sqr_l_lbound = NULL,
                      tau_sqr_l_ubound = NULL,
                      random = TRUE,
                      diag = FALSE,
                      effects = TRUE,
                      int_meas = FALSE,
                      int_dyn = FALSE,
                      cov_meas = FALSE,
                      cov_dyn = FALSE,
                      converged = TRUE,
                      grad_tol = 1e-2,
                      hess_tol = 1e-8,
                      vanishing_theta = TRUE,
                      theta_tol = 0.001,
                      try = 1000,
                      ncores = NULL,
                      ...) {
  stopifnot(
    inherits(
      object,
      "dtvarmxid"
    )
  )
  if (
    inherits(
      object,
      "dtvarmxid"
    )
  ) {
    y <- fitDTVARMxID:::coef.dtvarmxid(
      object = object,
      alpha = int_dyn,
      beta = effects,
      nu = int_meas,
      psi = cov_dyn,
      theta = cov_meas,
      converged = converged,
      grad_tol = grad_tol,
      hess_tol = hess_tol,
      vanishing_theta = vanishing_theta,
      theta_tol = theta_tol
    )
    v <- fitDTVARMxID:::vcov.dtvarmxid(
      object = object,
      alpha = int_dyn,
      beta = effects,
      nu = int_meas,
      psi = cov_dyn,
      theta = cov_meas,
      converged = converged,
      grad_tol = grad_tol,
      hess_tol = hess_tol,
      vanishing_theta = vanishing_theta,
      theta_tol = theta_tol
    )
  }
  out <- Meta(
    y = y,
    v = v,
    x = x,
    alpha_values = alpha_values,
    alpha_free = alpha_free,
    alpha_lbound = alpha_lbound,
    alpha_ubound = alpha_ubound,
    gamma_values = gamma_values,
    gamma_free = gamma_free,
    gamma_lbound = gamma_lbound,
    gamma_ubound = gamma_ubound,
    tau_sqr_d_free = tau_sqr_d_free,
    tau_sqr_d_values = tau_sqr_d_values,
    tau_sqr_d_lbound = tau_sqr_d_lbound,
    tau_sqr_d_ubound = tau_sqr_d_ubound,
    tau_sqr_l_free = tau_sqr_l_free,
    tau_sqr_l_values = tau_sqr_l_values,
    tau_sqr_l_lbound = tau_sqr_l_lbound,
    tau_sqr_l_ubound = tau_sqr_l_ubound,
    random = random,
    diag = diag,
    try = try,
    ncores = ncores,
    ...
  )
  out$call <- match.call()
  out$fun <- "MetaVARMx"
  out
}
